import { useMemo } from 'react';
import type { FinancialData, MonthlyBalance, CategoryTotal, DashboardStats, StatusOperacao } from '@/types';
import { MONTHS } from '@/types';

export function useCalculations(data: FinancialData, month: number | 'anual', year: number) {
  const parseDate = (dateStr: string): { y: number; m: number; d: number } | null => {
    if (!dateStr) return null;
    const parts = dateStr.split('-');
    if (parts.length !== 3) return null;
    return { y: +parts[0], m: +parts[1] - 1, d: +parts[2] };
  };

  const filterByMonth = <T extends { data?: string }>(arr: T[], m: number, y: number): T[] => {
    return arr.filter(x => {
      const p = x.data ? parseDate(x.data) : null;
      return p && p.m === m && p.y === y;
    });
  };

  const filterByYear = <T extends { data?: string }>(arr: T[], y: number): T[] => {
    return arr.filter(x => {
      const p = x.data ? parseDate(x.data) : null;
      return p && p.y === y;
    });
  };

  // Calcular variação percentual
  const calcVariacao = (atual: number, anterior: number): number => {
    if (anterior === 0) return atual > 0 ? 100 : 0;
    return ((atual - anterior) / anterior) * 100;
  };

  // Dados filtrados do período atual
  const filteredData = useMemo(() => {
    if (month === 'anual') {
      return {
        fixos: filterByYear(data.fixos, year),
        unicos: filterByYear(data.unicos, year),
        entradas: filterByYear(data.entradas, year)
      };
    }
    return {
      fixos: filterByMonth(data.fixos, month, year),
      unicos: filterByMonth(data.unicos, month, year),
      entradas: filterByMonth(data.entradas, month, year)
    };
  }, [data, month, year]);

  // Dados do período anterior para comparação
  const previousPeriodData = useMemo(() => {
    let prevMonth: number;
    let prevYear: number;

    if (month === 'anual') {
      prevYear = year - 1;
      prevMonth = 11;
    } else if (month === 0) {
      prevMonth = 11;
      prevYear = year - 1;
    } else {
      prevMonth = month - 1;
      prevYear = year;
    }

    return {
      fixos: filterByMonth(data.fixos, prevMonth, prevYear),
      unicos: filterByMonth(data.unicos, prevMonth, prevYear),
      entradas: filterByMonth(data.entradas, prevMonth, prevYear)
    };
  }, [data, month, year]);

  // Calcular MRR (receitas recorrentes)
  const calcularMRR = (entradas: typeof data.entradas) => {
    return entradas
      .filter(x => x.recorrente === 'mensal' || x.recorrente === 'proximo')
      .reduce((a, b) => a + Number(b.valor), 0);
  };

  // Estatísticas completas
  const stats: DashboardStats = useMemo(() => {
    const receitaAtual = filteredData.entradas.reduce((a, b) => a + Number(b.valor), 0);
    const receitaAnterior = previousPeriodData.entradas.reduce((a, b) => a + Number(b.valor), 0);
    
    const mrrAtual = calcularMRR(filteredData.entradas);
    const mrrAnterior = calcularMRR(previousPeriodData.entradas);
    
    const custosFixosAtual = filteredData.fixos.reduce((a, b) => a + Number(b.valor), 0);
    const custosFixosAnterior = previousPeriodData.fixos.reduce((a, b) => a + Number(b.valor), 0);
    
    const custosVariaveisAtual = filteredData.unicos.reduce((a, b) => a + Number(b.valor), 0);
    const custosVariaveisAnterior = previousPeriodData.unicos.reduce((a, b) => a + Number(b.valor), 0);
    
    const burnRateAtual = custosFixosAtual + custosVariaveisAtual;
    const burnRateAnterior = custosFixosAnterior + custosVariaveisAnterior;
    
    const resultadoLiquido = receitaAtual - burnRateAtual;
    const resultadoAnterior = receitaAnterior - burnRateAnterior;
    
    const margem = receitaAtual > 0 ? (resultadoLiquido / receitaAtual) * 100 : 0;
    
    // Caixa disponível (usar valor do banco ou padrão)
    const caixaAtual = data.caixa || 45000;
    const caixaAnterior = caixaAtual; // Simplificado - na prática viria do histórico
    
    // Runway = Caixa / Burn Rate
    const runway = burnRateAtual > 0 ? caixaAtual / burnRateAtual : 999;

    return {
      receita: receitaAtual,
      receitaVariacao: calcVariacao(receitaAtual, receitaAnterior),
      mrr: mrrAtual,
      mrrVariacao: calcVariacao(mrrAtual, mrrAnterior),
      burnRate: burnRateAtual,
      burnRateVariacao: calcVariacao(burnRateAtual, burnRateAnterior),
      custosFixos: custosFixosAtual,
      custosFixosVariacao: calcVariacao(custosFixosAtual, custosFixosAnterior),
      custosVariaveis: custosVariaveisAtual,
      custosVariaveisVariacao: calcVariacao(custosVariaveisAtual, custosVariaveisAnterior),
      resultadoLiquido,
      resultadoLiquidoVariacao: calcVariacao(resultadoLiquido, resultadoAnterior),
      margem,
      caixaDisponivel: caixaAtual,
      caixaVariacao: calcVariacao(caixaAtual, caixaAnterior),
      runway
    };
  }, [filteredData, previousPeriodData, data.caixa]);

  // Status da operação (automático)
  const statusOperacao: StatusOperacao = useMemo(() => {
    const { runway, resultadoLiquido, margem, burnRate, receita } = stats;
    
    // Regras de negócio
    if (runway >= 3 && resultadoLiquido >= 0 && margem >= 20) {
      return {
        nivel: 'saudavel',
        titulo: 'Operação Saudável',
        mensagem: `Runway de ${runway.toFixed(1)} meses. Continue monitorando.`,
        cor: 'success'
      };
    } else if (runway < 1 || (burnRate > receita && runway < 2)) {
      return {
        nivel: 'critico',
        titulo: 'Situação Crítica',
        mensagem: `Runway de apenas ${runway.toFixed(1)} meses. Ação imediata necessária!`,
        cor: 'destructive'
      };
    } else {
      return {
        nivel: 'atencao',
        titulo: 'Atenção Necessária',
        mensagem: `Runway de ${runway.toFixed(1)} meses. Monitore de perto.`,
        cor: 'warning'
      };
    }
  }, [stats]);

  // Balanços mensais
  const monthlyBalances: MonthlyBalance[] = useMemo(() => {
    return MONTHS.map((name, m) => {
      const income = filterByMonth(data.entradas, m, year).reduce((a, b) => a + Number(b.valor), 0);
      const fixos = filterByMonth(data.fixos, m, year).reduce((a, b) => a + Number(b.valor), 0);
      const variaveis = filterByMonth(data.unicos, m, year).reduce((a, b) => a + Number(b.valor), 0);
      const expense = fixos + variaveis;
      
      return {
        month: m,
        name,
        income,
        expense,
        balance: income - expense,
        fixos,
        variaveis
      };
    });
  }, [data, year]);

  // Totais por categoria
  const categoryTotals: CategoryTotal[] = useMemo(() => {
    const allExpenses = [...filteredData.fixos, ...filteredData.unicos];
    const catMap: Record<string, number> = {};
    
    allExpenses.forEach(x => {
      catMap[x.categoria] = (catMap[x.categoria] || 0) + Number(x.valor);
    });

    return Object.entries(catMap)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value);
  }, [filteredData]);

  // Dados para gráficos
  const chartData = useMemo(() => {
    const aRec: number[] = [];
    const aDesp: number[] = [];
    const aCats: string[] = [];

    for (let i = 5; i >= 0; i--) {
      const d = new Date();
      d.setDate(1);
      d.setMonth(d.getMonth() - i);
      const m = d.getMonth();
      const y = d.getFullYear();

      aRec.push(filterByMonth(data.entradas, m, y).reduce((a, b) => a + Number(b.valor), 0));
      aDesp.push(
        filterByMonth(data.fixos, m, y).reduce((a, b) => a + Number(b.valor), 0) +
        filterByMonth(data.unicos, m, y).reduce((a, b) => a + Number(b.valor), 0)
      );
      aCats.push(MONTHS[m].substring(0, 3));
    }

    return { income: aRec, expense: aDesp, labels: aCats };
  }, [data]);

  // Totais anuais
  const annualTotals = useMemo(() => {
    const totalIn = monthlyBalances.reduce((a, b) => a + b.income, 0);
    const totalOut = monthlyBalances.reduce((a, b) => a + b.expense, 0);
    const totalFixos = monthlyBalances.reduce((a, b) => a + b.fixos, 0);
    const totalVariaveis = monthlyBalances.reduce((a, b) => a + b.variaveis, 0);
    
    return { 
      income: totalIn, 
      expense: totalOut, 
      balance: totalIn - totalOut,
      fixos: totalFixos,
      variaveis: totalVariaveis
    };
  }, [monthlyBalances]);

  // Dados para DRE
  const dreData = useMemo(() => {
    const receitaBruta = filteredData.entradas
      .filter(e => e.status === 'Confirmado' || e.status === 'Pago')
      .reduce((a, b) => a + Number(b.valor), 0);
    
    const impostos = receitaBruta * 0.06; // 6% DAS Simples Nacional (estimativa)
    const receitaLiquida = receitaBruta - impostos;
    
    const custosFixos = filteredData.fixos.reduce((a, b) => a + Number(b.valor), 0);
    const custosVariaveis = filteredData.unicos.reduce((a, b) => a + Number(b.valor), 0);
    const custosTotais = custosFixos + custosVariaveis;
    
    const lucroBruto = receitaLiquida - custosTotais;
    const margemBruta = receitaLiquida > 0 ? (lucroBruto / receitaLiquida) * 100 : 0;
    
    return {
      receitaBruta,
      impostos,
      receitaLiquida,
      custosFixos,
      custosVariaveis,
      custosTotais,
      lucroBruto,
      margemBruta
    };
  }, [filteredData]);

  // CAC (Customer Acquisition Cost)
  const cac = useMemo(() => {
    const gastosMarketing = filteredData.unicos
      .filter(u => u.categoria === 'Tráfego Pago')
      .reduce((a, b) => a + Number(b.valor), 0);
    
    // Contar novos clientes (simplificado - receitas únicas do mês)
    const novosClientes = filteredData.entradas
      .filter(e => e.recorrente === 'unico' && (e.status === 'Confirmado' || e.status === 'Pago'))
      .length;
    
    return novosClientes > 0 ? gastosMarketing / novosClientes : 0;
  }, [filteredData]);

  // Projeções
  const projecoes = useMemo(() => {
    const cenarios = [
      { nome: 'Conservador', crescimento: 5, cor: 'text-muted-foreground' },
      { nome: 'Realista', crescimento: 15, cor: 'text-primary' },
      { nome: 'Agressivo', crescimento: 30, cor: 'text-success' }
    ];

    const receitaBase = stats.receita;
    const burnRateAtual = stats.burnRate;
    const caixaAtual = stats.caixaDisponivel;

    return cenarios.map(cenario => {
      const projecoes12Meses = [];
      let receitaAcumulada = receitaBase;
      let lucroAcumulado = 0;

      for (let i = 0; i < 12; i++) {
        receitaAcumulada = receitaAcumulada * (1 + cenario.crescimento / 100);
        const lucroMes = receitaAcumulada - burnRateAtual;
        lucroAcumulado += lucroMes;
        
        const runway = burnRateAtual > 0 ? (caixaAtual + lucroAcumulado) / burnRateAtual : 999;
        
        projecoes12Meses.push({
          mes: i + 1,
          receita: receitaAcumulada,
          lucro: lucroMes,
          lucroAcumulado,
          runway: Math.max(0, runway)
        });
      }

      return {
        ...cenario,
        projecoes: projecoes12Meses,
        receita12Meses: projecoes12Meses[11].receita,
        lucro12Meses: projecoes12Meses[11].lucroAcumulado
      };
    });
  }, [stats]);

  return {
    filteredData,
    stats,
    statusOperacao,
    monthlyBalances,
    categoryTotals,
    chartData,
    annualTotals,
    dreData,
    cac,
    projecoes,
    parseDate,
    filterByMonth,
    filterByYear
  };
}
