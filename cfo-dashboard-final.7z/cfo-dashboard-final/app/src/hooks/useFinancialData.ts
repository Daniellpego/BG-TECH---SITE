import { useState, useEffect, useCallback } from 'react';
import type { FinancialData, FinancialRecord, SyncStatus } from '@/types';
import { DB_CONFIG, DEFAULT_CAIXA } from '@/types';

export function useFinancialData() {
  const [data, setData] = useState<FinancialData>({
    fixos: [],
    unicos: [],
    entradas: [],
    caixa: DEFAULT_CAIXA
  });
  const [syncStatus, setSyncStatus] = useState<SyncStatus>({ status: 'ok', message: 'Conectado' });
  const [isLoading, setIsLoading] = useState(true);

  const fetchData = useCallback(async (silent = false) => {
    if (!silent) setSyncStatus({ status: 'loading', message: 'Sincronizando...' });
    
    try {
      const response = await fetch(DB_CONFIG.url, {
        headers: {
          apikey: DB_CONFIG.key,
          Authorization: `Bearer ${DB_CONFIG.key}`,
          'Cache-Control': 'no-cache'
        }
      });
      
      const result = await response.json();
      
      if (result && result[0]) {
        const parseData = (field: unknown): FinancialRecord[] => {
          if (Array.isArray(field)) return field;
          try {
            return JSON.parse(String(field || '[]'));
          } catch {
            return [];
          }
        };

        setData({
          fixos: parseData(result[0].fixos),
          unicos: parseData(result[0].unicos),
          entradas: parseData(result[0].entradas),
          caixa: result[0].caixa || DEFAULT_CAIXA
        });
      }
      
      setSyncStatus({ status: 'ok', message: 'Nuvem Conectada' });
    } catch (error) {
      setSyncStatus({ status: 'error', message: 'Modo Offline' });
      console.error('Error fetching data:', error);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const pushData = useCallback(async (newData: FinancialData) => {
    setSyncStatus({ status: 'loading', message: 'Salvando...' });
    
    try {
      await fetch(DB_CONFIG.url, {
        method: 'PATCH',
        headers: {
          apikey: DB_CONFIG.key,
          Authorization: `Bearer ${DB_CONFIG.key}`,
          'Content-Type': 'application/json',
          Prefer: 'return=minimal'
        },
        body: JSON.stringify({
          fixos: newData.fixos || [],
          unicos: newData.unicos || [],
          entradas: newData.entradas || [],
          caixa: newData.caixa || DEFAULT_CAIXA,
          updated_at: new Date().toISOString()
        })
      });
      
      setSyncStatus({ status: 'ok', message: 'Nuvem Conectada' });
      return true;
    } catch (error) {
      setSyncStatus({ status: 'error', message: 'Erro ao salvar' });
      console.error('Error pushing data:', error);
      return false;
    }
  }, []);

  const updateCaixa = useCallback(async (novoCaixa: number) => {
    const newData = { ...data, caixa: novoCaixa };
    setData(newData);
    return await pushData(newData);
  }, [data, pushData]);

  const addRecord = useCallback(async (type: keyof FinancialData, record: FinancialRecord) => {
    if (type === 'caixa') return false;
    const newData = {
      ...data,
      [type]: [...(data[type] as FinancialRecord[]), record]
    };
    setData(newData);
    return await pushData(newData);
  }, [data, pushData]);

  const updateRecord = useCallback(async (type: keyof FinancialData, id: string, updates: Partial<FinancialRecord>) => {
    if (type === 'caixa') return false;
    const newData = {
      ...data,
      [type]: (data[type] as FinancialRecord[]).map(r => r.id === id ? { ...r, ...updates } : r)
    };
    setData(newData);
    return await pushData(newData);
  }, [data, pushData]);

  const deleteRecord = useCallback(async (id: string) => {
    const newData = {
      ...data,
      fixos: data.fixos.filter(r => r.id !== id),
      unicos: data.unicos.filter(r => r.id !== id),
      entradas: data.entradas.filter(r => r.id !== id)
    };
    setData(newData);
    return await pushData(newData);
  }, [data, pushData]);

  const addMultipleRecords = useCallback(async (type: keyof FinancialData, records: FinancialRecord[]) => {
    if (type === 'caixa') return false;
    const newData = {
      ...data,
      [type]: [...(data[type] as FinancialRecord[]), ...records]
    };
    setData(newData);
    return await pushData(newData);
  }, [data, pushData]);

  useEffect(() => {
    fetchData();
    const interval = setInterval(() => fetchData(true), 15000);
    return () => clearInterval(interval);
  }, [fetchData]);

  return {
    data,
    syncStatus,
    isLoading,
    fetchData,
    addRecord,
    updateRecord,
    deleteRecord,
    addMultipleRecords,
    updateCaixa
  };
}
