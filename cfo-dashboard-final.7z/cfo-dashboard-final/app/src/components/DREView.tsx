import { motion } from 'framer-motion';
import { TrendingUp, DollarSign, Percent, Calculator } from 'lucide-react';

interface DREData {
  receitaBruta: number;
  impostos: number;
  receitaLiquida: number;
  custosFixos: number;
  custosVariaveis: number;
  custosTotais: number;
  lucroBruto: number;
  margemBruta: number;
}

interface DREViewProps {
  data: DREData;
  cac: number;
}

const formatCurrency = (val: number) => {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL'
  }).format(val);
};

export function DREView({ data, cac }: DREViewProps) {
  const { 
    receitaBruta, 
    impostos, 
    receitaLiquida, 
    custosFixos, 
    custosVariaveis, 
    custosTotais, 
    lucroBruto, 
    margemBruta 
  } = data;

  const linhas = [
    { 
      label: 'RECEITA BRUTA', 
      valor: receitaBruta, 
      tipo: 'receita' as const,
      descricao: 'Total de vendas e serviços'
    },
    { 
      label: '(-) Impostos', 
      valor: impostos, 
      tipo: 'despesa' as const,
      descricao: 'DAS Simples Nacional (estimado 6%)'
    },
    { 
      label: '(=) RECEITA LÍQUIDA', 
      valor: receitaLiquida, 
      tipo: 'total' as const,
      destaque: true
    },
    { 
      label: '(-) Custos Fixos', 
      valor: custosFixos, 
      tipo: 'despesa' as const,
      descricao: 'Despesas operacionais fixas'
    },
    { 
      label: '(-) Custos Variáveis', 
      valor: custosVariaveis, 
      tipo: 'despesa' as const,
      descricao: 'Marketing, impostos variáveis, etc'
    },
    { 
      label: '(=) CUSTOS TOTAIS', 
      valor: custosTotais, 
      tipo: 'total' as const,
      destaque: true
    },
    { 
      label: '(=) LUCRO BRUTO', 
      valor: lucroBruto, 
      tipo: lucroBruto >= 0 ? 'receita' : 'despesa' as const,
      destaque: true,
      isResultado: true
    },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      {/* Header */}
      <div className="glass rounded-2xl p-6">
        <div className="flex items-center gap-3 mb-4">
          <Calculator className="w-6 h-6 text-primary" />
          <h2 className="font-title text-2xl font-black text-white">
            DRE - Demonstração do Resultado
          </h2>
        </div>
        <p className="text-sm text-muted-foreground">
          Demonstração do Resultado do Exercício - Visão simplificada para tomada de decisão CFO
        </p>
      </div>

      {/* DRE Table */}
      <div className="glass rounded-2xl overflow-hidden">
        <div className="p-6">
          <h3 className="font-title text-lg font-bold text-white mb-6">Estrutura da DRE</h3>
          
          <div className="space-y-3">
            {linhas.map((linha, index) => (
              <motion.div
                key={linha.label}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
                className={`flex justify-between items-center p-4 rounded-xl ${
                  linha.destaque 
                    ? 'bg-white/5 border border-white/10' 
                    : 'hover:bg-white/[0.02]'
                }`}
              >
                <div>
                  <span className={`font-semibold ${
                    linha.destaque ? 'text-white text-lg' : 'text-muted-foreground'
                  }`}>
                    {linha.label}
                  </span>
                  {linha.descricao && (
                    <p className="text-xs text-muted-foreground mt-1">{linha.descricao}</p>
                  )}
                </div>
                <span className={`font-title text-xl font-black ${
                  linha.tipo === 'receita' 
                    ? 'text-success' 
                    : linha.tipo === 'despesa' 
                      ? 'text-destructive' 
                      : linha.isResultado && linha.valor >= 0
                        ? 'text-success'
                        : linha.isResultado
                          ? 'text-destructive'
                          : 'text-white'
                }`}>
                  {linha.tipo === 'despesa' && linha.valor > 0 ? '-' : ''}
                  {formatCurrency(Math.abs(linha.valor))}
                </span>
              </motion.div>
            ))}
          </div>
        </div>
      </div>

      {/* Indicadores */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="glass rounded-2xl p-6"
        >
          <div className="flex items-center gap-2 mb-3">
            <Percent className="w-5 h-5 text-primary" />
            <span className="text-sm font-bold uppercase tracking-wider text-muted-foreground">
              Margem Bruta
            </span>
          </div>
          <div className={`font-title text-3xl font-black ${
            margemBruta >= 30 ? 'text-success' : margemBruta >= 15 ? 'text-warning' : 'text-destructive'
          }`}>
            {margemBruta.toFixed(1)}%
          </div>
          <p className="text-xs text-muted-foreground mt-2">
            {margemBruta >= 30 
              ? 'Margem saudável' 
              : margemBruta >= 15 
                ? 'Margem adequada' 
                : 'Margem baixa - atenção'}
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="glass rounded-2xl p-6"
        >
          <div className="flex items-center gap-2 mb-3">
            <DollarSign className="w-5 h-5 text-primary" />
            <span className="text-sm font-bold uppercase tracking-wider text-muted-foreground">
              CAC (Custo de Aquisição)
            </span>
          </div>
          <div className="font-title text-3xl font-black text-white">
            {formatCurrency(cac)}
          </div>
          <p className="text-xs text-muted-foreground mt-2">
            Custo para adquirir cada novo cliente
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="glass rounded-2xl p-6"
        >
          <div className="flex items-center gap-2 mb-3">
            <TrendingUp className="w-5 h-5 text-primary" />
            <span className="text-sm font-bold uppercase tracking-wider text-muted-foreground">
              Break-even
            </span>
          </div>
          <div className="font-title text-3xl font-black text-white">
            {formatCurrency(custosTotais)}
          </div>
          <p className="text-xs text-muted-foreground mt-2">
            Ponto de equilíbrio mensal
          </p>
        </motion.div>
      </div>
    </motion.div>
  );
}
