import { useState } from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, AlertTriangle, Target, Calendar, PiggyBank } from 'lucide-react';

interface Projecao {
  nome: string;
  crescimento: number;
  cor: string;
  projecoes: {
    mes: number;
    receita: number;
    lucro: number;
    lucroAcumulado: number;
    runway: number;
  }[];
  receita12Meses: number;
  lucro12Meses: number;
}

interface ProjecoesViewProps {
  projecoes: Projecao[];
}

const formatCurrency = (val: number) => {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL'
  }).format(val);
};

export function ProjecoesView({ projecoes }: ProjecoesViewProps) {
  const [cenarioAtivo, setCenarioAtivo] = useState(1); // Realista por padrão
  const cenario = projecoes[cenarioAtivo];

  const coresCenario = [
    { bg: 'bg-muted/20', border: 'border-muted', text: 'text-muted-foreground' },
    { bg: 'bg-primary/20', border: 'border-primary', text: 'text-primary' },
    { bg: 'bg-success/20', border: 'border-success', text: 'text-success' }
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      {/* Header */}
      <div className="glass rounded-2xl p-6">
        <div className="flex items-center gap-3 mb-4">
          <Target className="w-6 h-6 text-primary" />
          <h2 className="font-title text-2xl font-black text-white">
            Projeções Financeiras
          </h2>
        </div>
        <p className="text-sm text-muted-foreground">
          Simulação de cenários futuros baseados em diferentes taxas de crescimento
        </p>
      </div>

      {/* Seletor de Cenários */}
      <div className="grid grid-cols-3 gap-4">
        {projecoes.map((c, index) => (
          <button
            key={c.nome}
            onClick={() => setCenarioAtivo(index)}
            className={`glass rounded-xl p-4 border-2 transition-all duration-300 ${
              cenarioAtivo === index 
                ? `${coresCenario[index].border} ${coresCenario[index].bg}` 
                : 'border-transparent hover:border-white/10'
            }`}
          >
            <div className={`text-sm font-bold uppercase tracking-wider mb-1 ${
              cenarioAtivo === index ? coresCenario[index].text : 'text-muted-foreground'
            }`}>
              {c.nome}
            </div>
            <div className="text-2xl font-black text-white">
              +{c.crescimento}%
            </div>
            <div className="text-xs text-muted-foreground mt-1">
              crescimento/mês
            </div>
          </button>
        ))}
      </div>

      {/* Resumo do Cenário */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <motion.div
          key={`receita-${cenarioAtivo}`}
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="glass rounded-2xl p-6"
        >
          <div className="flex items-center gap-2 mb-3">
            <TrendingUp className="w-5 h-5 text-success" />
            <span className="text-sm font-bold uppercase tracking-wider text-muted-foreground">
              Receita 12 Meses
            </span>
          </div>
          <div className="font-title text-2xl font-black text-success">
            {formatCurrency(cenario.receita12Meses)}
          </div>
        </motion.div>

        <motion.div
          key={`lucro-${cenarioAtivo}`}
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.1 }}
          className="glass rounded-2xl p-6"
        >
          <div className="flex items-center gap-2 mb-3">
            <PiggyBank className="w-5 h-5 text-primary" />
            <span className="text-sm font-bold uppercase tracking-wider text-muted-foreground">
              Lucro Acumulado
            </span>
          </div>
          <div className={`font-title text-2xl font-black ${
            cenario.lucro12Meses >= 0 ? 'text-success' : 'text-destructive'
          }`}>
            {formatCurrency(cenario.lucro12Meses)}
          </div>
        </motion.div>

        <motion.div
          key={`runway-${cenarioAtivo}`}
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2 }}
          className="glass rounded-2xl p-6"
        >
          <div className="flex items-center gap-2 mb-3">
            <Calendar className="w-5 h-5 text-warning" />
            <span className="text-sm font-bold uppercase tracking-wider text-muted-foreground">
              Runway Final
            </span>
          </div>
          <div className={`font-title text-2xl font-black ${
            cenario.projecoes[11].runway >= 3 ? 'text-success' : 
            cenario.projecoes[11].runway >= 1 ? 'text-warning' : 'text-destructive'
          }`}>
            {cenario.projecoes[11].runway.toFixed(1)} meses
          </div>
        </motion.div>
      </div>

      {/* Tabela de Projeções Mensais */}
      <div className="glass rounded-2xl overflow-hidden">
        <div className="p-6">
          <h3 className="font-title text-lg font-bold text-white mb-4">
            Projeção Mensal - {cenario.nome}
          </h3>
          
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border">
                  <th className="text-left py-3 px-4 text-xs font-bold uppercase tracking-wider text-muted-foreground">Mês</th>
                  <th className="text-right py-3 px-4 text-xs font-bold uppercase tracking-wider text-muted-foreground">Receita</th>
                  <th className="text-right py-3 px-4 text-xs font-bold uppercase tracking-wider text-muted-foreground">Lucro</th>
                  <th className="text-right py-3 px-4 text-xs font-bold uppercase tracking-wider text-muted-foreground">Lucro Acum.</th>
                  <th className="text-right py-3 px-4 text-xs font-bold uppercase tracking-wider text-muted-foreground">Runway</th>
                </tr>
              </thead>
              <tbody>
                {cenario.projecoes.map((p, index) => (
                  <motion.tr
                    key={p.mes}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.03 }}
                    className="border-b border-border/50 hover:bg-white/[0.02]"
                  >
                    <td className="py-3 px-4 text-sm font-medium text-white">{p.mes}</td>
                    <td className="py-3 px-4 text-right text-sm text-success font-semibold">
                      {formatCurrency(p.receita)}
                    </td>
                    <td className={`py-3 px-4 text-right text-sm font-semibold ${
                      p.lucro >= 0 ? 'text-success' : 'text-destructive'
                    }`}>
                      {formatCurrency(p.lucro)}
                    </td>
                    <td className={`py-3 px-4 text-right text-sm font-semibold ${
                      p.lucroAcumulado >= 0 ? 'text-success' : 'text-destructive'
                    }`}>
                      {formatCurrency(p.lucroAcumulado)}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <span className={`text-sm font-bold ${
                        p.runway >= 3 ? 'text-success' : 
                        p.runway >= 1 ? 'text-warning' : 'text-destructive'
                      }`}>
                        {p.runway.toFixed(1)}m
                      </span>
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Alerta de Runway */}
      {cenario.projecoes[11].runway < 3 && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass rounded-2xl p-6 border border-destructive/30 bg-destructive/10"
        >
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-6 h-6 text-destructive flex-shrink-0" />
            <div>
              <h4 className="font-bold text-destructive mb-1">Alerta de Runway</h4>
              <p className="text-sm text-muted-foreground">
                No cenário {cenario.nome.toLowerCase()}, o runway cai para {cenario.projecoes[11].runway.toFixed(1)} meses ao final do ano. 
                Considere aumentar a receita ou reduzir custos para manter a saúde financeira.
              </p>
            </div>
          </div>
        </motion.div>
      )}
    </motion.div>
  );
}
