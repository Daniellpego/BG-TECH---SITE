import { motion, AnimatePresence } from 'framer-motion';
import { Edit2, Trash2, CheckCircle, Clock, XCircle, AlertCircle, User } from 'lucide-react';
import type { FinancialRecord, RecordType } from '@/types';
import { Button } from '@/components/ui/button';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';

interface RecordTableProps {
  records: FinancialRecord[];
  type: RecordType;
  onEdit: (record: FinancialRecord) => void;
  onDelete: (id: string) => void;
}

export function RecordTable({ records, type, onEdit, onDelete }: RecordTableProps) {
  const sortedRecords = [...records].sort((a, b) => 
    (b.data || '').localeCompare(a.data || '')
  );

  const formatDate = (dateStr: string) => {
    if (!dateStr) return '--';
    const parts = dateStr.split('-');
    if (parts.length !== 3) return dateStr;
    return `${parts[2]}/${parts[1]}`;
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const isIncome = type === 'entradas';

  const getStatusConfig = (status: string) => {
    switch (status) {
      case 'Confirmado':
      case 'Pago':
        return { icon: CheckCircle, class: 'bg-success/10 text-success border-success/20', label: status };
      case 'Pendente':
        return { icon: Clock, class: 'bg-warning/10 text-warning border-warning/20', label: 'Pendente' };
      case 'Previsto':
        return { icon: AlertCircle, class: 'bg-primary/10 text-primary border-primary/20', label: 'Previsto' };
      case 'Cancelado':
        return { icon: XCircle, class: 'bg-destructive/10 text-destructive border-destructive/20', label: 'Cancelado' };
      default:
        return { icon: Clock, class: 'bg-muted/20 text-muted-foreground border-muted/30', label: status };
    }
  };

  if (sortedRecords.length === 0) {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="glass rounded-2xl p-12 text-center"
      >
        <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-primary/10 flex items-center justify-center">
          <CheckCircle className="w-8 h-8 text-primary" />
        </div>
        <h3 className="font-title text-xl font-bold text-white mb-2">
          Nenhum registro encontrado
        </h3>
        <p className="text-muted-foreground">
          Adicione um novo registro para começar a visualizar seus dados.
        </p>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="glass rounded-2xl overflow-hidden"
    >
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow className="border-border hover:bg-transparent">
              <TableHead className="text-xs font-extrabold uppercase tracking-[0.12em] text-muted-foreground">Data</TableHead>
              <TableHead className="text-xs font-extrabold uppercase tracking-[0.12em] text-muted-foreground">Descrição</TableHead>
              {isIncome && <TableHead className="text-xs font-extrabold uppercase tracking-[0.12em] text-muted-foreground">Cliente</TableHead>}
              <TableHead className="text-xs font-extrabold uppercase tracking-[0.12em] text-muted-foreground">Categoria</TableHead>
              <TableHead className="text-xs font-extrabold uppercase tracking-[0.12em] text-muted-foreground">Recorrência</TableHead>
              <TableHead className="text-xs font-extrabold uppercase tracking-[0.12em] text-muted-foreground">Status</TableHead>
              <TableHead className="text-xs font-extrabold uppercase tracking-[0.12em] text-muted-foreground text-right">Valor</TableHead>
              <TableHead className="text-xs font-extrabold uppercase tracking-[0.12em] text-muted-foreground text-center">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            <AnimatePresence>
              {sortedRecords.map((record, index) => {
                const isRecurring = record.recorrente === 'mensal' || record.recorrente === 'proximo';
                const amountColor = isIncome 
                  ? (record.status === 'Cancelado' ? 'text-muted-foreground' : 'text-success')
                  : 'text-white';
                const statusConfig = getStatusConfig(record.status);
                const StatusIcon = statusConfig.icon;

                return (
                  <motion.tr
                    key={record.id}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 10 }}
                    transition={{ delay: index * 0.05 }}
                    className="border-border hover:bg-primary/5 transition-colors"
                  >
                    <TableCell className="text-sm font-semibold text-muted-foreground">
                      {formatDate(record.data)}
                    </TableCell>
                    <TableCell>
                      <div className="font-medium text-white">{record.nome}</div>
                      {record.descricao && (
                        <div className="text-xs text-muted-foreground">{record.descricao}</div>
                      )}
                    </TableCell>
                    {isIncome && (
                      <TableCell>
                        {record.cliente && (
                          <div className="flex items-center gap-1 text-xs text-muted-foreground">
                            <User className="w-3 h-3" />
                            {record.cliente}
                          </div>
                        )}
                      </TableCell>
                    )}
                    <TableCell>
                      <span className="inline-flex px-3 py-1 rounded-lg text-xs font-bold bg-primary/10 text-primary border border-primary/20">
                        {record.categoria || '—'}
                      </span>
                    </TableCell>
                    <TableCell>
                      <span className={`inline-flex px-3 py-1 rounded-lg text-xs font-bold uppercase ${
                        isRecurring 
                          ? 'bg-success/10 text-success border border-success/20' 
                          : 'bg-muted/20 text-muted-foreground border border-muted/30'
                      }`}>
                        {isRecurring ? '🔄 Recorrente' : 'Único'}
                      </span>
                    </TableCell>
                    <TableCell>
                      <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-bold uppercase border ${statusConfig.class}`}>
                        <StatusIcon className="w-3 h-3" />
                        {statusConfig.label}
                      </span>
                    </TableCell>
                    <TableCell className={`text-right font-bold ${amountColor}`}>
                      {isIncome && record.status !== 'Cancelado' ? '+ ' : ''}
                      {formatCurrency(record.valor)}
                    </TableCell>
                    <TableCell className="text-center">
                      <div className="flex items-center justify-center gap-1">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => onEdit(record)}
                          className="h-9 w-9 text-muted-foreground hover:text-white hover:bg-white/10"
                        >
                          <Edit2 className="w-4 h-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => onDelete(record.id)}
                          className="h-9 w-9 text-muted-foreground hover:text-destructive hover:bg-destructive/10"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </motion.tr>
                );
              })}
            </AnimatePresence>
          </TableBody>
        </Table>
      </div>
    </motion.div>
  );
}
