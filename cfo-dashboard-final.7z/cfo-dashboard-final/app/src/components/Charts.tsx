import { motion } from 'framer-motion';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { LineChart, PieChart as PieIcon } from 'lucide-react';
import type { CategoryTotal } from '@/types';

interface AreaChartProps {
  data: {
    labels: string[];
    income: number[];
    expense: number[];
  };
}

interface DonutChartProps {
  data: CategoryTotal[];
}

const COLORS = ['#0ea5e9', '#38bdf8', '#7dd3fc', '#bae6fd', '#0284c7', '#0369a1', '#22d3ee', '#67e8f9'];

function CustomTooltip({ active, payload, label }: { active?: boolean; payload?: Array<{ name: string; value: number; color: string }>; label?: string }) {
  if (active && payload && payload.length) {
    return (
      <div className="chart-tooltip">
        <p className="text-sm font-semibold text-white mb-2">{label}</p>
        {payload.map((entry, index) => (
          <p key={index} className="text-sm" style={{ color: entry.color }}>
            {entry.name}: {new Intl.NumberFormat('pt-BR', {
              style: 'currency',
              currency: 'BRL'
            }).format(entry.value)}
          </p>
        ))}
      </div>
    );
  }
  return null;
}

function DonutTooltip({ active, payload }: { active?: boolean; payload?: Array<{ name: string; value: number }> }) {
  if (active && payload && payload.length) {
    const data = payload[0];
    return (
      <div className="chart-tooltip">
        <p className="text-sm font-semibold text-white">{data.name}</p>
        <p className="text-sm text-primary">
          {new Intl.NumberFormat('pt-BR', {
            style: 'currency',
            currency: 'BRL'
          }).format(data.value)}
        </p>
      </div>
    );
  }
  return null;
}

export function AreaChartComponent({ data }: AreaChartProps) {
  const chartData = data.labels.map((label, index) => ({
    name: label,
    Receitas: data.income[index],
    Despesas: data.expense[index]
  }));

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.2 }}
      className="glass rounded-2xl p-6 card-hover"
    >
      <div className="flex justify-between items-center mb-6 pb-4 border-b border-border">
        <div className="flex items-center gap-3">
          <LineChart className="w-5 h-5 text-primary" />
          <h3 className="font-title text-lg font-bold text-white">Lucratividade</h3>
        </div>
        <span className="text-xs text-muted-foreground">Últimos 6 meses</span>
      </div>

      <div className="h-[300px]">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={chartData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
            <defs>
              <linearGradient id="colorIncome" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#10b981" stopOpacity={0.5}/>
                <stop offset="95%" stopColor="#10b981" stopOpacity={0.05}/>
              </linearGradient>
              <linearGradient id="colorExpense" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#ef4444" stopOpacity={0.5}/>
                <stop offset="95%" stopColor="#ef4444" stopOpacity={0.05}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="4 4" stroke="rgba(255,255,255,0.05)" vertical={false} />
            <XAxis 
              dataKey="name" 
              stroke="#94a3b8" 
              fontSize={12}
              tickLine={false}
              axisLine={false}
            />
            <YAxis 
              stroke="#94a3b8" 
              fontSize={12}
              tickLine={false}
              axisLine={false}
              tickFormatter={(value) => `R$${(value / 1000).toFixed(0)}k`}
            />
            <Tooltip content={<CustomTooltip />} />
            <Area
              type="monotone"
              dataKey="Receitas"
              stroke="#10b981"
              strokeWidth={3}
              fillOpacity={1}
              fill="url(#colorIncome)"
              animationDuration={1000}
            />
            <Area
              type="monotone"
              dataKey="Despesas"
              stroke="#ef4444"
              strokeWidth={3}
              fillOpacity={1}
              fill="url(#colorExpense)"
              animationDuration={1000}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </motion.div>
  );
}

export function DonutChartComponent({ data }: DonutChartProps) {
  const hasData = data.length > 0;
  
  const chartData = hasData ? data : [{ name: 'Sem dados', value: 1 }];
  const colors = hasData ? COLORS : ['#1e293b'];

  const total = data.reduce((acc, item) => acc + item.value, 0);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.3 }}
      className="glass rounded-2xl p-6 card-hover"
    >
      <div className="flex justify-between items-center mb-6 pb-4 border-b border-border">
        <div className="flex items-center gap-3">
          <PieIcon className="w-5 h-5 text-primary" />
          <h3 className="font-title text-lg font-bold text-white">Composição de Despesas</h3>
        </div>
        <span className="text-xs text-muted-foreground">Por categoria</span>
      </div>

      <div className="h-[300px] relative">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={chartData}
              cx="50%"
              cy="50%"
              innerRadius={70}
              outerRadius={100}
              paddingAngle={4}
              dataKey="value"
              animationDuration={800}
              animationBegin={200}
            >
              {chartData.map((_entry, index) => (
                <Cell 
                  key={`cell-${index}`} 
                  fill={colors[index % colors.length]}
                  stroke="#0d1117"
                  strokeWidth={3}
                />
              ))}
            </Pie>
            <Tooltip content={<DonutTooltip />} />
          </PieChart>
        </ResponsiveContainer>
        
        {/* Center Label */}
        {hasData && (
          <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
            <span className="text-xs text-muted-foreground font-semibold">Total</span>
            <span className="font-title text-xl font-black text-white">
              {new Intl.NumberFormat('pt-BR', {
                style: 'currency',
                currency: 'BRL',
                notation: 'compact'
              }).format(total)}
            </span>
          </div>
        )}
      </div>

      {/* Legend */}
      {hasData && (
        <div className="mt-4 grid grid-cols-2 gap-2">
          {data.slice(0, 4).map((item, index) => (
            <div key={item.name} className="flex items-center gap-2">
              <div 
                className="w-3 h-3 rounded-full" 
                style={{ backgroundColor: COLORS[index % COLORS.length] }}
              />
              <span className="text-xs text-muted-foreground truncate">{item.name}</span>
            </div>
          ))}
        </div>
      )}
    </motion.div>
  );
}
