import { motion } from 'framer-motion';
import { 
  LayoutDashboard, 
  TrendingUp, 
  Anchor, 
  Zap, 
  CalendarRange, 
  Cpu,
  Menu,
  X,
  FileText,
  Target
} from 'lucide-react';
import type { TabType, SyncStatus } from '@/types';
import { Button } from '@/components/ui/button';

interface SidebarProps {
  activeTab: TabType;
  onTabChange: (tab: TabType) => void;
  syncStatus: SyncStatus;
  isOpen: boolean;
  onToggle: () => void;
}

const navItems: { id: TabType; label: string; icon: React.ElementType }[] = [
  { id: 'overview', label: 'Painel Geral', icon: LayoutDashboard },
  { id: 'dre', label: 'DRE', icon: FileText },
  { id: 'entradas', label: 'Receitas', icon: TrendingUp },
  { id: 'fixos', label: 'Custos Fixos', icon: Anchor },
  { id: 'unicos', label: 'Gastos Variáveis', icon: Zap },
  { id: 'annual', label: 'Balanço Anual', icon: CalendarRange },
  { id: 'projecoes', label: 'Projeções', icon: Target },
];

export function Sidebar({ activeTab, onTabChange, syncStatus, isOpen, onToggle }: SidebarProps) {
  const getSyncColor = () => {
    switch (syncStatus.status) {
      case 'loading': return 'bg-warning';
      case 'error': return 'bg-destructive';
      default: return 'bg-success';
    }
  };

  return (
    <>
      {/* Mobile Toggle */}
      <Button
        variant="ghost"
        size="icon"
        onClick={onToggle}
        className="fixed top-4 left-4 z-[60] lg:hidden glass rounded-xl"
      >
        {isOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
      </Button>

      {/* Overlay for mobile */}
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onToggle}
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[55] lg:hidden"
        />
      )}

      {/* Sidebar */}
      <motion.aside
        initial={{ x: -280 }}
        animate={{ x: isOpen ? 0 : -280 }}
        transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
        className={`fixed top-0 left-0 bottom-0 w-[280px] z-[56] flex flex-col glass-strong border-r border-border lg:translate-x-0`}
        style={{ 
          background: 'linear-gradient(180deg, rgba(3,7,18,0.98) 0%, rgba(13,17,23,0.95) 100%)'
        }}
      >
        {/* Logo */}
        <div className="flex items-center gap-3 px-6 py-8 relative">
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
          >
            <Cpu className="w-7 h-7 text-primary" />
          </motion.div>
          <h1 className="font-title text-xl font-black text-white tracking-tight">
            BG <span className="gradient-text">TECH</span>
          </h1>
          
          {/* Separator */}
          <div className="absolute bottom-4 left-6 right-6 h-px bg-gradient-to-r from-transparent via-border to-transparent" />
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-4 py-4 space-y-1 overflow-y-auto">
          {navItems.map((item, index) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            
            return (
              <motion.button
                key={item.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
                onClick={() => {
                  onTabChange(item.id);
                  if (window.innerWidth < 1024) onToggle();
                }}
                className={`relative w-full flex items-center gap-3 px-4 py-3.5 rounded-xl text-sm font-semibold transition-all duration-300 overflow-hidden group ${
                  isActive
                    ? 'bg-primary/15 text-primary border border-primary/25 nav-active'
                    : 'text-muted-foreground hover:text-white hover:bg-white/5'
                }`}
              >
                {/* Hover shine effect */}
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-primary/10 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-700" />
                
                <Icon className={`w-[18px] h-[18px] transition-transform duration-300 ${isActive ? 'scale-110' : 'group-hover:scale-110'}`} />
                <span className="relative z-10">{item.label}</span>
              </motion.button>
            );
          })}
        </nav>

        {/* Footer */}
        <div className="p-4">
          <div className="flex items-center gap-3 px-4 py-3 bg-black/40 border border-border rounded-xl">
            <div className={`w-2 h-2 rounded-full ${getSyncColor()} pulse-dot`} 
              style={{ 
                boxShadow: `0 0 12px ${syncStatus.status === 'loading' ? 'hsl(var(--warning))' : syncStatus.status === 'error' ? 'hsl(var(--destructive))' : 'hsl(var(--success))'}` 
              }} 
            />
            <span className="text-xs font-semibold text-muted-foreground">
              {syncStatus.message}
            </span>
          </div>
        </div>
      </motion.aside>
    </>
  );
}
