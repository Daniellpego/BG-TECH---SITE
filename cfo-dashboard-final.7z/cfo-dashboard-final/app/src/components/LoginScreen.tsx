import { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Cpu, ShieldCheck, User, Key, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

interface LoginScreenProps {
  onLogin: () => void;
}

export function LoginScreen({ onLogin }: LoginScreenProps) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const cardRef = useRef<HTMLDivElement>(null);

  const handleLogin = async () => {
    setIsLoading(true);
    
    await new Promise(resolve => setTimeout(resolve, 500));
    
    // Credenciais atualizadas: gustavo / admin2024
    if (username.toLowerCase() === 'gustavo' && password === 'admin2024') {
      setError(false);
      onLogin();
    } else {
      setError(true);
      setPassword('');
      setIsLoading(false);
      
      if (cardRef.current) {
        cardRef.current.classList.add('shake');
        setTimeout(() => cardRef.current?.classList.remove('shake'), 500);
      }
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      if (e.currentTarget.id === 'username') {
        document.getElementById('password')?.focus();
      } else {
        handleLogin();
      }
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center"
      style={{
        background: 'radial-gradient(ellipse at center, #0a0f1a 0%, #030712 100%)'
      }}
    >
      {/* Background Effects */}
      <div className="bg-grid !z-0" />
      <div className="glow-orb glow-orb-1 !z-0" />
      <div className="glow-orb glow-orb-2 !z-0" />

      {/* Card Container */}
      <motion.div
        ref={cardRef}
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: -20 }}
        transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
        className="relative z-10 w-full max-w-md mx-4"
      >
        <div className="glass rounded-3xl p-10 md:p-12 border border-primary/20 shadow-2xl">
          {/* Logo */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="flex items-center justify-center gap-3 mb-6"
          >
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
            >
              <Cpu className="w-12 h-12 text-primary" />
            </motion.div>
            <h1 className="font-title text-4xl md:text-5xl font-black text-white tracking-tight">
              BG <span className="gradient-text">TECH</span>
            </h1>
          </motion.div>

          {/* Badge */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3 }}
            className="flex justify-center mb-10"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/30">
              <ShieldCheck className="w-4 h-4 text-primary" />
              <span className="text-xs font-bold uppercase tracking-widest text-primary">
                Acesso Restrito CFO
              </span>
            </div>
          </motion.div>

          {/* Form */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="space-y-4"
          >
            {/* Username Input */}
            <div className="relative">
              <User className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground pointer-events-none z-10" />
              <Input
                id="username"
                type="text"
                placeholder="ID de Acesso"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                onKeyDown={handleKeyDown}
                className={`w-full pl-12 pr-4 h-14 bg-black/60 border rounded-xl text-white placeholder:text-muted-foreground focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all relative z-0 ${
                  error ? 'border-destructive' : 'border-border'
                }`}
                autoComplete="username"
                autoFocus
              />
            </div>

            {/* Password Input */}
            <div className="relative">
              <Key className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground pointer-events-none z-10" />
              <Input
                id="password"
                type="password"
                placeholder="Senha do Cofre"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                onKeyDown={handleKeyDown}
                className={`w-full pl-12 pr-4 h-14 bg-black/60 border rounded-xl text-white placeholder:text-muted-foreground focus:border-primary focus:ring-2 focus:ring-primary/20 transition-all relative z-0 ${
                  error ? 'border-destructive' : 'border-border'
                }`}
                autoComplete="current-password"
              />
            </div>

            <AnimatePresence>
              {error && (
                <motion.p
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="text-destructive text-sm text-center font-medium"
                >
                  Credenciais inválidas. Tente novamente.
                </motion.p>
              )}
            </AnimatePresence>

            <Button
              onClick={handleLogin}
              disabled={isLoading}
              className="w-full h-14 text-lg font-bold bg-gradient-to-r from-primary to-primary/80 hover:brightness-110 transition-all btn-shine"
            >
              {isLoading ? (
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                  className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full"
                />
              ) : (
                <>
                  Destrancar Sistema
                  <ArrowRight className="w-5 h-5 ml-2" />
                </>
              )}
            </Button>
          </motion.div>

          {/* Hustle Badge */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.6 }}
            className="flex justify-center mt-8"
          >
            <div className="inline-flex items-center gap-3 px-5 py-3 rounded-full bg-primary/5 border border-primary/20">
              <svg
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="text-primary run-icon"
              >
                <circle cx="16" cy="4" r="2" />
                <path d="M12 10l-4-4-4 2" />
                <path d="M12 10l2 4 4 2" />
                <path d="M14 14l-2 6" />
                <path d="M14 14l4 5" />
                <line x1="2" y1="12" x2="6" y2="12" className="speed-line" />
                <line x1="0" y1="16" x2="4" y2="16" className="speed-line" style={{ animationDelay: '0.2s' }} />
              </svg>
              <span className="font-title text-xs font-black uppercase tracking-[0.2em] text-primary">
                O corre nunca para
              </span>
            </div>
          </motion.div>
        </div>
      </motion.div>
    </motion.div>
  );
}
