import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Download, FileText, Table } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

interface ExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onExport: (format: 'pdf' | 'csv', monthsBack: number) => void;
}

export function ExportModal({ isOpen, onClose, onExport }: ExportModalProps) {
  const [format, setFormat] = useState<'pdf' | 'csv'>('pdf');
  const [period, setPeriod] = useState<string>('1');

  const handleExport = () => {
    onExport(format, parseInt(period));
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Overlay */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/80 backdrop-blur-xl z-[202]"
          />

          {/* Modal */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
            className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-md z-[203]"
          >
            <div 
              className="glass-strong rounded-3xl p-8 border border-primary/30"
              style={{ boxShadow: '0 40px 100px rgba(0,0,0,0.9)' }}
            >
              {/* Header */}
              <div className="flex justify-between items-center mb-8">
                <h3 className="font-title text-2xl font-black text-white flex items-center gap-3">
                  <FileText className="w-6 h-6 text-primary" />
                  Gerar Relatório
                </h3>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={onClose}
                  className="text-muted-foreground hover:text-white"
                >
                  <X className="w-5 h-5" />
                </Button>
              </div>

              {/* Form */}
              <div className="space-y-6">
                {/* Format */}
                <div className="space-y-2">
                  <Label className="text-xs font-extrabold uppercase tracking-wider text-muted-foreground">
                    Formato do Arquivo
                  </Label>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      onClick={() => setFormat('pdf')}
                      className={`flex items-center justify-center gap-3 py-4 px-4 rounded-xl border transition-all duration-300 ${
                        format === 'pdf'
                          ? 'border-primary bg-primary/10 text-white'
                          : 'border-border bg-black/30 text-muted-foreground hover:border-primary/30'
                      }`}
                    >
                      <FileText className="w-5 h-5" />
                      <span className="font-semibold">PDF</span>
                    </button>
                    <button
                      onClick={() => setFormat('csv')}
                      className={`flex items-center justify-center gap-3 py-4 px-4 rounded-xl border transition-all duration-300 ${
                        format === 'csv'
                          ? 'border-primary bg-primary/10 text-white'
                          : 'border-border bg-black/30 text-muted-foreground hover:border-primary/30'
                      }`}
                    >
                      <Table className="w-5 h-5" />
                      <span className="font-semibold">CSV</span>
                    </button>
                  </div>
                </div>

                {/* Period */}
                <div className="space-y-2">
                  <Label className="text-xs font-extrabold uppercase tracking-wider text-muted-foreground">
                    Período de Referência
                  </Label>
                  <Select value={period} onValueChange={setPeriod}>
                    <SelectTrigger className="bg-black/50 border-border text-white py-6">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-card border-border">
                      <SelectItem value="1">📅 Mês Atual</SelectItem>
                      <SelectItem value="3">📅 Trimestre (Últimos 3 meses)</SelectItem>
                      <SelectItem value="6">📅 Semestre (Últimos 6 meses)</SelectItem>
                      <SelectItem value="12">📅 Anual (Este Ano Inteiro)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Export Button */}
                <Button
                  onClick={handleExport}
                  className="w-full py-6 text-lg font-bold bg-gradient-to-r from-primary to-primary/80 hover:brightness-110 transition-all btn-shine mt-4"
                >
                  <Download className="w-5 h-5 mr-2" />
                  Gerar e Baixar
                </Button>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
