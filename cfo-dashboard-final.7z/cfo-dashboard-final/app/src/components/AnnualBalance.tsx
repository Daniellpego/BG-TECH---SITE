import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { MousePointer2, TrendingUp, TrendingDown, X, ChevronRight, Wallet, PiggyBank, TrendingDown as TrendingDownIcon } from 'lucide-react';
import type { MonthlyBalance } from '@/types';

interface AnnualBalanceProps {
  monthlyBalances: MonthlyBalance[];
  year: number;
  totalIncome: number;
  totalExpense: number;
  onMonthClick: (month: number) => void;
}

export function AnnualBalance({ 
  monthlyBalances, 
  year, 
  totalIncome, 
  totalExpense, 
  onMonthClick 
}: AnnualBalanceProps) {
  const currentMonth = new Date().getMonth();
  const currentYear = new Date().getFullYear();
  const [selectedMonth, setSelectedMonth] = useState<MonthlyBalance | null>(null);
  
  const maxValue = Math.max(
    ...monthlyBalances.map(m => Math.max(m.income, m.expense)),
    1
  );

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(val);
  };

  const handleMonthClick = (month: MonthlyBalance) => {
    setSelectedMonth(month);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-6"
    >
      {/* Header Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass rounded-2xl p-6 stat-border-success"
        >
          <div className="flex items-center gap-2 mb-3">
            <TrendingUp className="w-5 h-5 text-success" />
            <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
              Faturamento do Ano
            </span>
          </div>
          <div className="font-title text-3xl font-black text-success">
            {formatCurrency(totalIncome)}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="glass rounded-2xl p-6 stat-border-danger"
        >
          <div className="flex items-center gap-2 mb-3">
            <TrendingDown className="w-5 h-5 text-destructive" />
            <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
              Gastos do Ano
            </span>
          </div>
          <div className="font-title text-3xl font-black text-destructive">
            {formatCurrency(totalExpense)}
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className={`glass rounded-2xl p-6 ${
            totalIncome - totalExpense >= 0 ? 'stat-border-success' : 'stat-border-danger'
          }`}
        >
          <div className="flex items-center gap-2 mb-3">
            <PiggyBank className="w-5 h-5 text-primary" />
            <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
              Saldo Anual
            </span>
          </div>
          <div className={`font-title text-3xl font-black ${
            totalIncome - totalExpense >= 0 ? 'text-success' : 'text-destructive'
          }`}>
            {formatCurrency(totalIncome - totalExpense)}
          </div>
        </motion.div>
      </div>

      {/* Grid de Meses */}
      <div className="glass rounded-2xl p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="font-title text-2xl font-black text-white mb-1">
              Visão Mensal {year}
            </h2>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <MousePointer2 className="w-4 h-4" />
              <span>Clique em um mês para detalhes</span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {monthlyBalances.map((month, index) => {
            const isCurrent = month.month === currentMonth && year === currentYear;
            const pctIn = Math.round((month.income / maxValue) * 100);
            const pctOut = Math.round((month.expense / maxValue) * 100);
            const isPositive = month.balance >= 0;

            return (
              <motion.button
                key={month.month}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                whileHover={{ y: -4, scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => handleMonthClick(month)}
                className={`relative p-5 rounded-xl border text-left transition-all duration-300 group ${
                  isCurrent 
                    ? 'border-primary/50 bg-primary/10 shadow-lg shadow-primary/10' 
                    : isPositive
                      ? 'border-success/20 bg-success/5 hover:bg-success/10 hover:border-success/30'
                      : 'border-destructive/20 bg-destructive/5 hover:bg-destructive/10 hover:border-destructive/30'
                }`}
              >
                {/* Month Name */}
                <div className="flex justify-between items-center mb-3">
                  <span className="text-sm font-bold text-muted-foreground group-hover:text-white transition-colors">
                    {month.name.substring(0, 3)}
                  </span>
                  {isCurrent && (
                    <span className="text-[10px] font-extrabold uppercase tracking-wider text-primary bg-primary/20 px-2 py-0.5 rounded">
                      ATUAL
                    </span>
                  )}
                </div>

                {/* Values */}
                <div className="space-y-2 mb-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-success">+</span>
                    <span className="text-xs font-bold text-success">
                      {formatCurrency(month.income).replace('R$', '')}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-xs text-destructive">-</span>
                    <span className="text-xs font-bold text-destructive">
                      {formatCurrency(month.expense).replace('R$', '')}
                    </span>
                  </div>
                </div>

                {/* Progress Bar */}
                <div className="month-progress mb-3">
                  <div 
                    className="bg-success transition-all duration-500"
                    style={{ width: `${pctIn}%` }}
                  />
                  <div 
                    className="bg-destructive transition-all duration-500"
                    style={{ width: `${pctOut}%` }}
                  />
                </div>

                {/* Balance */}
                <div className={`text-right text-xs font-bold ${
                  isPositive ? 'text-success' : 'text-destructive'
                }`}>
                  {isPositive ? '+' : ''}{formatCurrency(month.balance)}
                </div>
              </motion.button>
            );
          })}
        </div>
      </div>

      {/* Modal de Detalhes do Mês */}
      <AnimatePresence>
        {selectedMonth && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedMonth(null)}
              className="fixed inset-0 bg-black/80 backdrop-blur-xl z-[200]"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-lg z-[201]"
            >
              <div className="glass-strong rounded-3xl p-8 border border-border">
                <div className="flex justify-between items-center mb-6">
                  <h3 className="font-title text-2xl font-black text-white">
                    {selectedMonth.name} {year}
                  </h3>
                  <button
                    onClick={() => setSelectedMonth(null)}
                    className="p-2 rounded-lg hover:bg-white/10 text-muted-foreground hover:text-white transition-colors"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="space-y-4">
                  <div className="flex justify-between items-center p-4 rounded-xl bg-success/10 border border-success/20">
                    <div className="flex items-center gap-3">
                      <TrendingUp className="w-5 h-5 text-success" />
                      <span className="text-sm font-medium text-white">Entradas</span>
                    </div>
                    <span className="font-title text-xl font-black text-success">
                      {formatCurrency(selectedMonth.income)}
                    </span>
                  </div>

                  <div className="flex justify-between items-center p-4 rounded-xl bg-destructive/10 border border-destructive/20">
                    <div className="flex items-center gap-3">
                      <Wallet className="w-5 h-5 text-destructive" />
                      <span className="text-sm font-medium text-white">Custos Fixos</span>
                    </div>
                    <span className="font-title text-xl font-black text-destructive">
                      {formatCurrency(selectedMonth.fixos)}
                    </span>
                  </div>

                  <div className="flex justify-between items-center p-4 rounded-xl bg-destructive/10 border border-destructive/20">
                    <div className="flex items-center gap-3">
                      <TrendingDownIcon className="w-5 h-5 text-destructive" />
                      <span className="text-sm font-medium text-white">Gastos Variáveis</span>
                    </div>
                    <span className="font-title text-xl font-black text-destructive">
                      {formatCurrency(selectedMonth.variaveis)}
                    </span>
                  </div>

                  <div className="h-px bg-border my-4" />

                  <div className={`flex justify-between items-center p-4 rounded-xl border ${
                    selectedMonth.balance >= 0 
                      ? 'bg-success/10 border-success/20' 
                      : 'bg-destructive/10 border-destructive/20'
                  }`}>
                    <div className="flex items-center gap-3">
                      <PiggyBank className={`w-5 h-5 ${
                        selectedMonth.balance >= 0 ? 'text-success' : 'text-destructive'
                      }`} />
                      <span className="text-sm font-medium text-white">Saldo do Mês</span>
                    </div>
                    <span className={`font-title text-2xl font-black ${
                      selectedMonth.balance >= 0 ? 'text-success' : 'text-destructive'
                    }`}>
                      {formatCurrency(selectedMonth.balance)}
                    </span>
                  </div>
                </div>

                <button
                  onClick={() => {
                    setSelectedMonth(null);
                    onMonthClick(selectedMonth.month);
                  }}
                  className="w-full mt-6 py-4 rounded-xl bg-primary/10 border border-primary/30 text-primary font-bold hover:bg-primary/20 transition-colors flex items-center justify-center gap-2"
                >
                  Ver detalhes completos
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
