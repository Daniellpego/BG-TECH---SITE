import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Save } from 'lucide-react';
import type { FinancialRecord, RecordType, RecurrenceType } from '@/types';
import { CATEGORIES, TIPOS_RECEITA } from '@/types';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

interface RecordDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (record: Partial<FinancialRecord>, type: RecordType, isEdit: boolean) => void;
  editRecord?: FinancialRecord | null;
  defaultType?: RecordType;
}

export function RecordDrawer({ isOpen, onClose, onSave, editRecord, defaultType = 'entradas' }: RecordDrawerProps) {
  const [type, setType] = useState<RecordType>(defaultType);
  const [nome, setNome] = useState('');
  const [valor, setValor] = useState('');
  const [data, setData] = useState('');
  const [categoria, setCategoria] = useState('');
  const [status, setStatus] = useState<StatusType>('Pago');
  const [recorrente, setRecorrente] = useState<RecurrenceType>('unico');
  const [descricao, setDescricao] = useState('');
  const [cliente, setCliente] = useState('');
  const [tipoReceita, setTipoReceita] = useState<string | undefined>(undefined);

  type StatusType = 'Pago' | 'Pendente' | 'Previsto' | 'Confirmado' | 'Cancelado';

  useEffect(() => {
    if (editRecord) {
      setNome(editRecord.nome);
      setValor(formatCurrency(editRecord.valor));
      setData(editRecord.data);
      setCategoria(editRecord.categoria);
      setStatus(editRecord.status as StatusType);
      setRecorrente(editRecord.recorrente);
      setDescricao(editRecord.descricao || '');
      setCliente(editRecord.cliente || '');
      setTipoReceita(editRecord.tipoReceita || '');
    } else {
      setType(defaultType);
      setNome('');
      setValor('');
      setData(new Date().toISOString().split('T')[0]);
      setCategoria(CATEGORIES[defaultType][0]);
      setStatus(defaultType === 'entradas' ? 'Confirmado' : 'Pago');
      setRecorrente('unico');
      setDescricao('');
      setCliente('');
      setTipoReceita('');
    }
  }, [editRecord, defaultType, isOpen]);

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('pt-BR', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    }).format(val);
  };

  const handleMoneyInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    let v = e.target.value.replace(/\D/g, '');
    if (!v) {
      setValor('');
      return;
    }
    v = (parseInt(v) / 100).toFixed(2);
    setValor(v.replace('.', ',').replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.'));
  };

  const cleanMoney = (s: string): number => {
    return parseFloat((s || '0').replace(/\./g, '').replace(',', '.')) || 0;
  };

  const handleSave = () => {
    const cleanValor = cleanMoney(valor);
    if (!nome.trim() || cleanValor <= 0) return;

    const record: Partial<FinancialRecord> = {
      id: editRecord?.id,
      nome: nome.trim(),
      valor: cleanValor,
      data,
      categoria,
      status,
      recorrente,
      descricao: descricao.trim(),
      cliente: cliente.trim(),
      tipoReceita: (tipoReceita as FinancialRecord['tipoReceita']) || undefined
    };

    onSave(record, type, !!editRecord);
  };

  const typeTabs: { id: RecordType; label: string; emoji: string }[] = [
    { id: 'entradas', label: 'Entrada', emoji: '💰' },
    { id: 'fixos', label: 'Custo Fixo', emoji: '📌' },
    { id: 'unicos', label: 'Variável', emoji: '⚡' },
  ];

  const getStatusOptions = () => {
    if (type === 'entradas') {
      return [
        { value: 'Previsto', label: '🟡 Previsto' },
        { value: 'Confirmado', label: '🟢 Confirmado' },
        { value: 'Cancelado', label: '🔴 Cancelado' }
      ];
    }
    return [
      { value: 'Pago', label: '✅ Pago' },
      { value: 'Pendente', label: '⏳ Pendente' }
    ];
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Overlay */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/80 backdrop-blur-xl z-[200]"
          />

          {/* Drawer */}
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
            className="fixed top-0 right-0 bottom-0 w-full max-w-xl z-[201] overflow-y-auto"
            style={{
              background: 'linear-gradient(180deg, #0d1117 0%, #070a0f 100%)',
              borderLeft: '1px solid hsl(var(--border))',
              boxShadow: '-40px 0 80px rgba(0,0,0,0.8)'
            }}
          >
            <div className="p-8 md:p-10">
              {/* Header */}
              <div className="flex justify-between items-center mb-8">
                <h2 className="font-title text-2xl font-black text-white">
                  {editRecord ? 'Editar Registro' : 'Novo Registro'}
                </h2>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={onClose}
                  className="text-muted-foreground hover:text-white"
                >
                  <X className="w-6 h-6" />
                </Button>
              </div>

              {/* Type Tabs */}
              {!editRecord && (
                <div className="flex bg-black/50 border border-border rounded-xl p-1.5 gap-1.5 mb-8">
                  {typeTabs.map((tab) => (
                    <button
                      key={tab.id}
                      onClick={() => {
                        setType(tab.id);
                        setCategoria(CATEGORIES[tab.id][0]);
                      }}
                      className={`flex-1 py-3 px-4 rounded-lg font-bold text-sm transition-all duration-300 ${
                        type === tab.id
                          ? 'bg-white/10 text-white'
                          : 'text-muted-foreground hover:text-white hover:bg-white/5'
                      }`}
                    >
                      <span className="mr-2">{tab.emoji}</span>
                      {tab.label}
                    </button>
                  ))}
                </div>
              )}

              {/* Form */}
              <div className="space-y-6">
                {/* Description */}
                <div className="space-y-2">
                  <Label className="text-xs font-extrabold uppercase tracking-wider text-muted-foreground">
                    Descrição *
                  </Label>
                  <Input
                    value={nome}
                    onChange={(e) => setNome(e.target.value)}
                    placeholder="Ex: Cliente XYZ, Servidor AWS..."
                    className="bg-black/50 border-border text-white placeholder:text-muted-foreground focus:border-primary input-glow py-6"
                  />
                </div>

                {/* Cliente (apenas para entradas) */}
                {type === 'entradas' && (
                  <div className="space-y-2">
                    <Label className="text-xs font-extrabold uppercase tracking-wider text-muted-foreground">
                      Cliente
                    </Label>
                    <Input
                      value={cliente}
                      onChange={(e) => setCliente(e.target.value)}
                      placeholder="Nome do cliente"
                      className="bg-black/50 border-border text-white placeholder:text-muted-foreground focus:border-primary input-glow py-6"
                    />
                  </div>
                )}

                {/* Value and Date */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="text-xs font-extrabold uppercase tracking-wider text-muted-foreground">
                      Valor (R$) *
                    </Label>
                    <Input
                      value={valor}
                      onChange={handleMoneyInput}
                      placeholder="0,00"
                      className="bg-black/50 border-border text-white placeholder:text-muted-foreground focus:border-primary input-glow py-6"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-xs font-extrabold uppercase tracking-wider text-muted-foreground">
                      Data
                    </Label>
                    <Input
                      type="date"
                      value={data}
                      onChange={(e) => setData(e.target.value)}
                      className="bg-black/50 border-border text-white focus:border-primary input-glow py-6"
                    />
                  </div>
                </div>

                {/* Tipo de Receita (apenas para entradas) */}
                {type === 'entradas' && (
                  <div className="space-y-2">
                    <Label className="text-xs font-extrabold uppercase tracking-wider text-muted-foreground">
                      Tipo de Receita
                    </Label>
                    <Select value={tipoReceita} onValueChange={setTipoReceita}>
                      <SelectTrigger className="bg-black/50 border-border text-white py-6">
                        <SelectValue placeholder="Selecione o tipo" />
                      </SelectTrigger>
                      <SelectContent className="bg-card border-border">
                        {TIPOS_RECEITA.map((tipo) => (
                          <SelectItem key={tipo} value={tipo}>{tipo}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}

                {/* Recurrence */}
                <div className="space-y-2">
                  <Label className="text-xs font-extrabold uppercase tracking-wider text-muted-foreground">
                    Recorrência
                  </Label>
                  <Select value={recorrente} onValueChange={(v) => setRecorrente(v as RecurrenceType)}>
                    <SelectTrigger className="bg-black/50 border-border text-white py-6">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-card border-border">
                      <SelectItem value="unico">🔴 Único</SelectItem>
                      <SelectItem value="mensal">🔄 Mensal</SelectItem>
                      <SelectItem value="proximo">📅 Próximos Meses</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Category */}
                <div className="space-y-2">
                  <Label className="text-xs font-extrabold uppercase tracking-wider text-muted-foreground">
                    Categoria
                  </Label>
                  <Select value={categoria} onValueChange={setCategoria}>
                    <SelectTrigger className="bg-black/50 border-border text-white py-6">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-card border-border">
                      {CATEGORIES[type].map((cat) => (
                        <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Status */}
                <div className="space-y-2">
                  <Label className="text-xs font-extrabold uppercase tracking-wider text-muted-foreground">
                    Status
                  </Label>
                  <Select value={status} onValueChange={(v) => setStatus(v as StatusType)}>
                    <SelectTrigger className="bg-black/50 border-border text-white py-6">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-card border-border">
                      {getStatusOptions().map((opt) => (
                        <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Description (optional) */}
                <div className="space-y-2">
                  <Label className="text-xs font-extrabold uppercase tracking-wider text-muted-foreground">
                    Observações
                  </Label>
                  <Input
                    value={descricao}
                    onChange={(e) => setDescricao(e.target.value)}
                    placeholder="Detalhes adicionais..."
                    className="bg-black/50 border-border text-white placeholder:text-muted-foreground focus:border-primary input-glow py-6"
                  />
                </div>

                {/* Save Button */}
                <Button
                  onClick={handleSave}
                  disabled={!nome.trim() || !valor}
                  className="w-full py-6 text-lg font-bold bg-gradient-to-r from-primary to-primary/80 hover:brightness-110 transition-all btn-shine mt-8"
                >
                  <Save className="w-5 h-5 mr-2" />
                  Salvar Registro
                </Button>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
