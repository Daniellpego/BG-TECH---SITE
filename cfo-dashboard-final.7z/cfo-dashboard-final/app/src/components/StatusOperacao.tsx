import { motion } from 'framer-motion';
import { CheckCircle, AlertTriangle, AlertOctagon, Clock } from 'lucide-react';
import type { StatusOperacao as StatusType } from '@/types';

interface StatusOperacaoProps {
  status: StatusType;
}

const iconMap = {
  saudavel: CheckCircle,
  atencao: AlertTriangle,
  critico: AlertOctagon
};

const colorMap = {
  saudavel: {
    bg: 'bg-success/10',
    border: 'border-success/30',
    text: 'text-success',
    icon: 'text-success',
    glow: 'shadow-success/20'
  },
  atencao: {
    bg: 'bg-warning/10',
    border: 'border-warning/30',
    text: 'text-warning',
    icon: 'text-warning',
    glow: 'shadow-warning/20'
  },
  critico: {
    bg: 'bg-destructive/10',
    border: 'border-destructive/30',
    text: 'text-destructive',
    icon: 'text-destructive',
    glow: 'shadow-destructive/20'
  }
};

export function StatusOperacaoCard({ status }: StatusOperacaoProps) {
  const Icon = iconMap[status.nivel];
  const colors = colorMap[status.nivel];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: 0.1 }}
      className={`glass rounded-2xl p-6 border ${colors.border} ${colors.bg} shadow-lg ${colors.glow}`}
    >
      <div className="flex items-start gap-4">
        <div className={`p-3 rounded-xl bg-background/50 ${colors.icon}`}>
          <Icon className="w-8 h-8" />
        </div>
        
        <div className="flex-1">
          <h3 className={`font-title text-xl font-black ${colors.text} mb-1`}>
            {status.titulo}
          </h3>
          <p className="text-sm text-muted-foreground">
            {status.mensagem}
          </p>
          
          {/* Indicadores rápidos */}
          <div className="flex flex-wrap gap-4 mt-4">
            <div className="flex items-center gap-2 text-xs">
              <Clock className="w-4 h-4 text-muted-foreground" />
              <span className="text-muted-foreground">Atualizado: {new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })}</span>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
