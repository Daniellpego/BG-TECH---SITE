import { useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, TrendingDown, Minus, Wallet, TrendingDown as TrendingDownIcon, Layers, PiggyBank, Timer, DollarSign, Percent } from 'lucide-react';

interface StatCardProps {
  title: string;
  value: number;
  subtitle?: string;
  type: 'success' | 'primary' | 'danger' | 'warning' | 'neutral';
  icon: 'income' | 'mrr' | 'burn' | 'fixos' | 'variaveis' | 'resultado' | 'caixa' | 'runway' | 'margem';
  delay?: number;
  variacao?: number; // Variação percentual vs período anterior
  format?: 'currency' | 'number' | 'percent' | 'months';
  isNegativeGood?: boolean; // Se true, variação negativa é boa (ex: redução de custos)
}

const iconMap = {
  income: { icon: DollarSign },
  mrr: { icon: Layers },
  burn: { icon: TrendingDownIcon },
  fixos: { icon: Wallet },
  variaveis: { icon: TrendingDownIcon },
  resultado: { icon: Percent },
  caixa: { icon: PiggyBank },
  runway: { icon: Timer },
  margem: { icon: Percent }
};

const typeStyles = {
  success: 'stat-border-success',
  primary: 'stat-border-primary',
  danger: 'stat-border-danger',
  warning: 'stat-border-warning',
  neutral: 'border-t-2 border-muted'
};

const glowStyles = {
  success: 'glow-success',
  primary: 'glow-primary',
  danger: 'glow-danger',
  warning: '',
  neutral: ''
};

const colorMap = {
  success: 'text-success',
  primary: 'text-primary',
  danger: 'text-destructive',
  warning: 'text-warning',
  neutral: 'text-muted-foreground'
};

export function StatCard({ 
  title, 
  value, 
  subtitle, 
  type, 
  icon, 
  delay = 0, 
  variacao = 0,
  format = 'currency',
  isNegativeGood = false
}: StatCardProps) {
  const [displayValue, setDisplayValue] = useState(0);
  const previousValue = useRef(0);
  const { icon: Icon } = iconMap[icon];

  useEffect(() => {
    const startValue = previousValue.current;
    const endValue = Math.abs(value);
    const duration = 800;
    const startTime = performance.now();

    const animate = (currentTime: number) => {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const easeProgress = 1 - Math.pow(1 - progress, 3);
      const current = startValue + (endValue - startValue) * easeProgress;
      
      setDisplayValue(current);
      
      if (progress < 1) {
        requestAnimationFrame(animate);
      } else {
        previousValue.current = endValue;
      }
    };

    requestAnimationFrame(animate);
  }, [value]);

  const formatValue = (val: number) => {
    switch (format) {
      case 'currency':
        return new Intl.NumberFormat('pt-BR', {
          style: 'currency',
          currency: 'BRL'
        }).format(val);
      case 'percent':
        return `${val.toFixed(1)}%`;
      case 'months':
        return `${val.toFixed(1)} meses`;
      default:
        return new Intl.NumberFormat('pt-BR').format(val);
    }
  };

  const isNegative = value < 0;
  const displayPrefix = isNegative ? '- ' : '';
  
  // Determinar cor da variação
  const variacaoIsPositive = variacao > 0;
  const variacaoIsGood = isNegativeGood ? !variacaoIsPositive : variacaoIsPositive;
  const variacaoColor = variacao === 0 ? 'text-muted-foreground' : (variacaoIsGood ? 'text-success' : 'text-destructive');
  const VariacaoIcon = variacao > 0 ? TrendingUp : (variacao < 0 ? TrendingDown : Minus);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay, ease: [0.16, 1, 0.3, 1] }}
      whileHover={{ y: -4, transition: { duration: 0.2 } }}
      className={`glass rounded-2xl p-6 card-hover ${typeStyles[type]} ${glowStyles[type]}`}
    >
      {/* Header */}
      <div className="flex justify-between items-start mb-3">
        <div className="flex items-center gap-2">
          <div className={`p-2 rounded-lg bg-${type === 'success' ? 'success' : type === 'danger' ? 'destructive' : 'primary'}/10`}>
            <Icon className={`w-4 h-4 ${colorMap[type]}`} />
          </div>
          <span className="text-xs font-extrabold uppercase tracking-[0.1em] text-muted-foreground">
            {title}
          </span>
        </div>
        
        {/* Variação */}
        {variacao !== 0 && (
          <div className={`flex items-center gap-1 text-xs font-bold ${variacaoColor}`}>
            <VariacaoIcon className="w-3 h-3" />
            {Math.abs(variacao).toFixed(1)}%
          </div>
        )}
      </div>

      {/* Value */}
      <div className={`font-title text-2xl md:text-3xl font-black tracking-tight ${colorMap[type]}`}>
        {displayPrefix}{formatValue(displayValue)}
      </div>

      {/* Subtitle */}
      {subtitle && (
        <div className="flex items-center gap-2 mt-2 text-xs text-muted-foreground font-medium">
          <span>{subtitle}</span>
        </div>
      )}
    </motion.div>
  );
}
