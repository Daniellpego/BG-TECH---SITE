import { useState, useCallback, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Plus, FileDown, Activity } from 'lucide-react';
import { LoginScreen } from '@/components/LoginScreen';
import { Sidebar } from '@/components/Sidebar';
import { StatCard } from '@/components/StatCard';
import { AreaChartComponent, DonutChartComponent } from '@/components/Charts';
import { RecordTable } from '@/components/RecordTable';
import { AnnualBalance } from '@/components/AnnualBalance';
import { RecordDrawer } from '@/components/RecordDrawer';
import { ExportModal } from '@/components/ExportModal';
import { ToastContainer } from '@/components/ToastContainer';
import { StatusOperacaoCard } from '@/components/StatusOperacao';
import { DREView } from '@/components/DREView';
import { ProjecoesView } from '@/components/ProjecoesView';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { useFinancialData } from '@/hooks/useFinancialData';
import { useCalculations } from '@/hooks/useCalculations';
import { useToast } from '@/hooks/useToast';
import type { TabType, RecordType, FinancialRecord } from '@/types';
import { MONTHS } from '@/types';
import jsPDF from 'jspdf';
import 'jspdf-autotable';

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [activeTab, setActiveTab] = useState<TabType>('overview');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [selectedMonth, setSelectedMonth] = useState<number | 'anual'>('anual');
  const [selectedYear, setSelectedYear] = useState(2026);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [exportModalOpen, setExportModalOpen] = useState(false);
  const [editingRecord, setEditingRecord] = useState<FinancialRecord | null>(null);

  const { data, syncStatus, addRecord, updateRecord, deleteRecord, addMultipleRecords } = useFinancialData();
  const { toasts, addToast, removeToast } = useToast();
  const { 
    stats, 
    statusOperacao,
    filteredData, 
    monthlyBalances, 
    categoryTotals, 
    chartData, 
    annualTotals, 
    dreData,
    cac,
    projecoes,
    filterByYear 
  } = useCalculations(data, selectedMonth, selectedYear);

  const handleLogin = useCallback(() => {
    setIsLoggedIn(true);
  }, []);

  const handleTabChange = useCallback((tab: TabType) => {
    setActiveTab(tab);
  }, []);

  const handleMonthClick = useCallback((month: number) => {
    setSelectedMonth(month);
    setActiveTab('overview');
  }, []);

  const openNewRecord = useCallback(() => {
    setEditingRecord(null);
    setDrawerOpen(true);
  }, []);

  const openEditRecord = useCallback((record: FinancialRecord) => {
    setEditingRecord(record);
    setDrawerOpen(true);
  }, []);

  const handleSaveRecord = useCallback(async (record: Partial<FinancialRecord>, type: RecordType, isEdit: boolean) => {
    if (isEdit && record.id) {
      await updateRecord(type, record.id, record);
      addToast('Registro atualizado! ✅');
    } else {
      const baseRecord = {
        ...record,
        id: `bgt_${Date.now()}`
      } as FinancialRecord;

      if (record.recorrente === 'mensal') {
        const [y, , d] = (record.data || '').split('-');
        const records: FinancialRecord[] = [];
        for (let m = 0; m < 12; m++) {
          records.push({
            ...baseRecord,
            id: `bgt_${Date.now()}_${m}`,
            data: `${y}-${String(m + 1).padStart(2, '0')}-${d}`
          });
        }
        await addMultipleRecords(type, records);
        addToast('12 lançamentos criados! ✨');
      } else if (record.recorrente === 'proximo') {
        const [y, mo, d] = (record.data || '').split('-');
        const startM = parseInt(mo) - 1;
        const records: FinancialRecord[] = [];
        let count = 0;
        for (let m = startM; m < 12; m++) {
          records.push({
            ...baseRecord,
            id: `bgt_${Date.now()}_${m}`,
            data: `${y}-${String(m + 1).padStart(2, '0')}-${d}`
          });
          count++;
        }
        await addMultipleRecords(type, records);
        addToast(`${count} lançamentos criados! ✨`);
      } else {
        await addRecord(type, baseRecord);
        addToast('Registro salvo! ✅');
      }
    }
    setDrawerOpen(false);
  }, [addRecord, updateRecord, addMultipleRecords, addToast]);

  const handleDelete = useCallback(async (id: string) => {
    if (confirm('Excluir permanentemente este registro?')) {
      await deleteRecord(id);
      addToast('Registro excluído. 🗑️');
    }
  }, [deleteRecord, addToast]);

  const handleExport = useCallback((format: 'pdf' | 'csv', monthsBack: number) => {
    interface ExportRecord extends FinancialRecord {
      fluxo: 'Entrada' | 'Saída (Fixo)' | 'Saída (Variável)';
    }

    const allData: ExportRecord[] = [];
    data.entradas.forEach(d => allData.push({ ...d, fluxo: 'Entrada' }));
    data.fixos.forEach(d => allData.push({ ...d, fluxo: 'Saída (Fixo)' }));
    data.unicos.forEach(d => allData.push({ ...d, fluxo: 'Saída (Variável)' }));

    const now = new Date();
    const curM = now.getMonth();
    const curY = now.getFullYear();

    let filtered: ExportRecord[] = [];
    if (monthsBack === 12) {
      filtered = filterByYear(allData, curY);
    } else {
      filtered = allData.filter(d => {
        const p = d.data?.split('-').map(Number);
        if (!p || p.length !== 3) return false;
        const itemDate = new Date(p[0], p[1] - 1, 1);
        const limitDate = new Date(curY, curM - monthsBack + 1, 1);
        const endDate = new Date(curY, curM + 1, 0);
        return itemDate >= limitDate && itemDate <= endDate;
      });
    }

    filtered.sort((a, b) => (a.data || '').localeCompare(b.data || ''));
    const filename = `Relatorio_Financeiro_BGTech_${monthsBack}M`;

    const formatDate = (dateStr: string) => {
      if (!dateStr) return '--';
      const parts = dateStr.split('-');
      if (parts.length !== 3) return dateStr;
      return `${parts[2]}/${parts[1]}`;
    };

    const formatCurrency = (val: number) => {
      return new Intl.NumberFormat('pt-BR', {
        style: 'currency',
        currency: 'BRL'
      }).format(val);
    };

    if (format === 'csv') {
      const rows = [['Data', 'Fluxo', 'Descrição', 'Categoria', 'Status', 'Valor']];
      filtered.forEach(d => {
        rows.push([formatDate(d.data), d.fluxo, d.nome, d.categoria, d.status, String(d.valor)]);
      });
      const link = document.createElement('a');
      link.setAttribute('href', encodeURI('data:text/csv;charset=utf-8,' + rows.map(e => e.join(',')).join('\n')));
      link.setAttribute('download', filename + '.csv');
      document.body.appendChild(link);
      link.click();
      link.remove();
    } else {
      const doc = new jsPDF();
      doc.setFontSize(16);
      doc.text('Relatório Financeiro - BG Tech', 14, 20);
      doc.setFontSize(10);
      doc.text(`Período: Últimos ${monthsBack} meses`, 14, 28);
      (doc as any).autoTable({
        startY: 35,
        head: [['Data', 'Fluxo', 'Descrição', 'Categoria', 'Status', 'Valor (R$)']],
        body: filtered.map(d => [
          formatDate(d.data),
          d.fluxo,
          d.nome,
          d.categoria,
          d.status,
          formatCurrency(d.valor)
        ]),
        theme: 'grid',
        headStyles: { fillColor: [14, 165, 233] },
        styles: { fontSize: 8 }
      });
      doc.save(filename + '.pdf');
    }

    addToast(`Relatório ${format.toUpperCase()} baixado! 📥`);
  }, [data, filterByYear, addToast]);

  const getPageInfo = () => {
    const titles: Record<TabType, [string, string]> = {
      overview: ['Painel Geral', 'Visão executiva do CFO - Caixa, resultado e tendência'],
      dre: ['DRE', 'Demonstração do Resultado do Exercício'],
      annual: ['Balanço Anual', 'Visão consolidada do ano'],
      entradas: ['Receitas', 'Faturamento e pagamentos recebidos'],
      fixos: ['Custos Fixos', 'Despesas recorrentes da operação'],
      unicos: ['Gastos Variáveis', 'Despesas pontuais e extras'],
      projecoes: ['Projeções', 'Cenários futuros e simulações']
    };
    return titles[activeTab];
  };

  const [pageTitle, pageSubtitle] = getPageInfo();

  const getListRecords = () => {
    switch (activeTab) {
      case 'entradas': return filteredData.entradas;
      case 'fixos': return filteredData.fixos;
      case 'unicos': return filteredData.unicos;
      default: return [];
    }
  };

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setDrawerOpen(false);
        setExportModalOpen(false);
      }
    };
    document.addEventListener('keydown', handleEscape);
    return () => document.removeEventListener('keydown', handleEscape);
  }, []);

  return (
    <div className="min-h-screen bg-background">
      <AnimatePresence mode="wait">
        {!isLoggedIn ? (
          <LoginScreen key="login" onLogin={handleLogin} />
        ) : (
          <motion.div
            key="app"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6 }}
            className="flex"
          >
            {/* Background Effects */}
            <div className="bg-grid" />
            <div className="glow-orb glow-orb-1" />
            <div className="glow-orb glow-orb-2" />

            {/* Sidebar */}
            <Sidebar
              activeTab={activeTab}
              onTabChange={handleTabChange}
              syncStatus={syncStatus}
              isOpen={sidebarOpen}
              onToggle={() => setSidebarOpen(!sidebarOpen)}
            />

            {/* Main Content */}
            <main className="flex-1 lg:ml-[280px] min-w-0 p-6 md:p-10 relative z-10">
              {/* Header */}
              <header className="flex flex-col lg:flex-row justify-between items-start lg:items-end gap-6 mb-10 pb-6 border-b border-border">
                <div>
                  <motion.h1
                    key={pageTitle}
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="font-title text-3xl md:text-4xl font-black text-white tracking-tight"
                  >
                    {pageTitle}
                  </motion.h1>
                  <motion.p
                    key={pageSubtitle}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.1 }}
                    className="flex items-center gap-2 mt-2 text-muted-foreground"
                  >
                    <Activity className="w-4 h-4" />
                    {pageSubtitle}
                  </motion.p>
                </div>

                <div className="flex flex-wrap items-center gap-4">
                  {/* Filters */}
                  <div className="flex bg-black/60 border border-border rounded-xl overflow-hidden">
                    <Select 
                      value={selectedMonth.toString()} 
                      onValueChange={(v) => setSelectedMonth(v === 'anual' ? 'anual' : parseInt(v))}
                    >
                      <SelectTrigger className="w-[140px] bg-transparent border-0 text-white py-3">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-card border-border">
                        <SelectItem value="anual">📊 Ano Todo</SelectItem>
                        {MONTHS.map((m, i) => (
                          <SelectItem key={i} value={i.toString()}>{m}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <div className="w-px bg-border my-2" />
                    <Select value={selectedYear.toString()} onValueChange={(v) => setSelectedYear(parseInt(v))}>
                      <SelectTrigger className="w-[100px] bg-transparent border-0 text-white py-3">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-card border-border">
                        <SelectItem value="2025">2025</SelectItem>
                        <SelectItem value="2026">2026</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Export Button */}
                  <Button
                    variant="outline"
                    onClick={() => setExportModalOpen(true)}
                    className="border-border bg-white/5 hover:bg-white/10 text-muted-foreground hover:text-white"
                  >
                    <FileDown className="w-4 h-4 mr-2" />
                    Exportar
                  </Button>

                  {/* New Record Button */}
                  {activeTab !== 'dre' && activeTab !== 'projecoes' && activeTab !== 'annual' && (
                    <Button
                      onClick={openNewRecord}
                      className="bg-gradient-to-r from-primary to-primary/80 hover:brightness-110 btn-shine"
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Novo Registro
                    </Button>
                  )}
                </div>
              </header>

              {/* Content Views */}
              <AnimatePresence mode="wait">
                {activeTab === 'overview' && (
                  <motion.div
                    key="overview"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    transition={{ duration: 0.4 }}
                    className="space-y-6"
                  >
                    {/* Status da Operação */}
                    <StatusOperacaoCard status={statusOperacao} />

                    {/* Stats Grid - Primeira Linha */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                      <StatCard
                        title="Receita Total"
                        value={stats.receita}
                        subtitle="Inclui pontuais e recorrentes"
                        type="success"
                        icon="income"
                        delay={0}
                        variacao={stats.receitaVariacao}
                      />
                      <StatCard
                        title="MRR"
                        value={stats.mrr}
                        subtitle="Receita recorrente mensal"
                        type="primary"
                        icon="mrr"
                        delay={0.05}
                        variacao={stats.mrrVariacao}
                      />
                      <StatCard
                        title="Burn Rate Mensal"
                        value={stats.burnRate}
                        subtitle="Custos Fixos + Variáveis"
                        type="danger"
                        icon="burn"
                        delay={0.1}
                        variacao={stats.burnRateVariacao}
                        isNegativeGood={true}
                      />
                      <StatCard
                        title="Resultado Líquido"
                        value={stats.resultadoLiquido}
                        subtitle={`Margem: ${stats.margem.toFixed(1)}%`}
                        type={stats.resultadoLiquido >= 0 ? 'success' : 'danger'}
                        icon="resultado"
                        delay={0.15}
                        variacao={stats.resultadoLiquidoVariacao}
                      />
                    </div>

                    {/* Stats Grid - Segunda Linha */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                      <StatCard
                        title="Custos Fixos"
                        value={stats.custosFixos}
                        subtitle="Despesas recorrentes"
                        type="neutral"
                        icon="fixos"
                        delay={0.2}
                        variacao={stats.custosFixosVariacao}
                        isNegativeGood={true}
                      />
                      <StatCard
                        title="Custos Variáveis"
                        value={stats.custosVariaveis}
                        subtitle="Gastos do período"
                        type="neutral"
                        icon="variaveis"
                        delay={0.25}
                        variacao={stats.custosVariaveisVariacao}
                        isNegativeGood={true}
                      />
                      <StatCard
                        title="Caixa Disponível"
                        value={stats.caixaDisponivel}
                        subtitle="Saldo em conta"
                        type="primary"
                        icon="caixa"
                        delay={0.3}
                      />
                      <StatCard
                        title="Runway"
                        value={stats.runway}
                        subtitle="Meses de sobrevivência"
                        type={stats.runway >= 3 ? 'success' : stats.runway >= 1 ? 'warning' : 'danger'}
                        icon="runway"
                        delay={0.35}
                        format="months"
                      />
                    </div>

                    {/* Charts */}
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                      <div className="lg:col-span-2">
                        <AreaChartComponent data={chartData} />
                      </div>
                      <div>
                        <DonutChartComponent data={categoryTotals} />
                      </div>
                    </div>
                  </motion.div>
                )}

                {activeTab === 'dre' && (
                  <motion.div
                    key="dre"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    transition={{ duration: 0.4 }}
                  >
                    <DREView data={dreData} cac={cac} />
                  </motion.div>
                )}

                {activeTab === 'projecoes' && (
                  <motion.div
                    key="projecoes"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    transition={{ duration: 0.4 }}
                  >
                    <ProjecoesView projecoes={projecoes} />
                  </motion.div>
                )}

                {(activeTab === 'entradas' || activeTab === 'fixos' || activeTab === 'unicos') && (
                  <motion.div
                    key="list"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    transition={{ duration: 0.4 }}
                  >
                    <RecordTable
                      records={getListRecords()}
                      type={activeTab}
                      onEdit={openEditRecord}
                      onDelete={handleDelete}
                    />
                  </motion.div>
                )}

                {activeTab === 'annual' && (
                  <motion.div
                    key="annual"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    transition={{ duration: 0.4 }}
                  >
                    <AnnualBalance
                      monthlyBalances={monthlyBalances}
                      year={selectedYear}
                      totalIncome={annualTotals.income}
                      totalExpense={annualTotals.expense}
                      onMonthClick={handleMonthClick}
                    />
                  </motion.div>
                )}
              </AnimatePresence>
            </main>

            {/* Modals */}
            <RecordDrawer
              isOpen={drawerOpen}
              onClose={() => setDrawerOpen(false)}
              onSave={handleSaveRecord}
              editRecord={editingRecord}
              defaultType={activeTab === 'overview' || activeTab === 'annual' || activeTab === 'dre' || activeTab === 'projecoes' ? 'entradas' : activeTab}
            />

            <ExportModal
              isOpen={exportModalOpen}
              onClose={() => setExportModalOpen(false)}
              onExport={handleExport}
            />

            {/* Toasts */}
            <ToastContainer toasts={toasts} onRemove={removeToast} />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default App;
