export interface FinancialRecord {
  id: string;
  nome: string;
  valor: number;
  data: string;
  categoria: string;
  status: 'Pago' | 'Pendente' | 'Previsto' | 'Confirmado' | 'Cancelado';
  descricao?: string;
  recorrente: 'unico' | 'mensal' | 'proximo';
  fluxo?: 'Entrada' | 'Saída (Fixo)' | 'Saída (Variável)';
  cliente?: string;
  tipoReceita?: 'Projeto único' | 'MVP' | 'Mensalidade recorrente' | 'Setup inicial' | 'Consultoria estratégica' | 'Outro';
}

export interface FinancialData {
  fixos: FinancialRecord[];
  unicos: FinancialRecord[];
  entradas: FinancialRecord[];
  caixa?: number; // Caixa disponível
}

export type TabType = 'overview' | 'entradas' | 'fixos' | 'unicos' | 'annual' | 'dre' | 'projecoes';
export type RecordType = 'entradas' | 'fixos' | 'unicos';
export type RecurrenceType = 'unico' | 'mensal' | 'proximo';
export type StatusType = 'Pago' | 'Pendente' | 'Previsto' | 'Confirmado' | 'Cancelado';

export interface MonthlyBalance {
  month: number;
  name: string;
  income: number;
  expense: number;
  balance: number;
  fixos: number;
  variaveis: number;
}

export interface CategoryTotal {
  name: string;
  value: number;
  color?: string;
}

export interface DashboardStats {
  receita: number;
  receitaVariacao: number; // % vs período anterior
  mrr: number;
  mrrVariacao: number;
  burnRate: number;
  burnRateVariacao: number;
  custosFixos: number;
  custosFixosVariacao: number;
  custosVariaveis: number;
  custosVariaveisVariacao: number;
  resultadoLiquido: number;
  resultadoLiquidoVariacao: number;
  margem: number;
  caixaDisponivel: number;
  caixaVariacao: number;
  runway: number; // meses
}

export interface SyncStatus {
  status: 'loading' | 'ok' | 'error';
  message: string;
}

export interface StatusOperacao {
  nivel: 'saudavel' | 'atencao' | 'critico';
  titulo: string;
  mensagem: string;
  cor: string;
}

export interface ProjecaoCenario {
  nome: string;
  crescimentoMensal: number; // %
  novosClientesMes: number;
  ticketMedio: number;
  receitaProjetada: number[];
  custosFixosProjetados: number[];
  custosVariaveisProjetados: number[];
  lucroProjetado: number[];
  runwayProjetado: number[];
}

export const MONTHS = [
  'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
  'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
];

export const CATEGORIES = {
  entradas: [
    'Serviços B2B',
    'Consultoria',
    'Mensalidade / SaaS',
    'Venda Avulsa',
    'Outras Receitas'
  ],
  fixos: [
    'Software e Automação',
    'Nuvem e Infra',
    'Pró-labore e Equipe',
    'Marketing Fixo',
    'Estrutura',
    'Outros Custos Fixos'
  ],
  unicos: [
    'Hardware e Peças',
    'Tráfego Pago',
    'Impostos e Taxas',
    'Terceirizados',
    'Eventos',
    'Gasto Não Previsto'
  ]
};

export const TIPOS_RECEITA = [
  'Projeto único',
  'MVP',
  'Mensalidade recorrente',
  'Setup inicial',
  'Consultoria estratégica',
  'Outro'
];

export const DB_CONFIG = {
  url: 'https://urpuiznydrlwmaqhdids.supabase.co/rest/v1/painel_gastos?id=eq.1',
  key: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVycHVpem55ZHJsd21hcWhkaWRzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzczMTM5OTcsImV4cCI6MjA1Mjg4OTk5N30.1yOEoCa5jS6eqXaEPGaO_VBH6Bfv3AqNmGEOnN0xXYg'
};

// Valores padrão para demonstração
export const DEFAULT_CAIXA = 45000; // R$ 45.000 de caixa inicial
