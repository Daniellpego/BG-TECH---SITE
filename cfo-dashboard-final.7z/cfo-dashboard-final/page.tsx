"use client";

import React, { useState, useEffect, useCallback, useMemo, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import { createClient } from "@supabase/supabase-js";
import jsPDF from "jspdf";
import autoTable from "jspdf-autotable";
import * as XLSX from "xlsx";
import {
  LayoutDashboard,
  TrendingUp,
  TrendingDown,
  FileText,
  LineChart as LineChartIcon,
  LogOut,
  Plus,
  Trash2,
  Download,
  FileSpreadsheet,
  File as FileIcon,
  Repeat,
  Flame,
  Wallet,
  Percent,
  Banknote,
  Timer,
  ArrowUpCircle,
  ArrowDownCircle,
  Rocket,
  CheckCircle,
  AlertTriangle,
  AlertOctagon,
  X,
  Inbox,
  Loader2,
  Zap,
  BarChart3,
  User,
} from "lucide-react";

// ============================================
// CONFIGURAÇÃO SUPABASE
// ============================================
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || "";
const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "";

// Cliente Supabase singleton
let supabaseInstance: ReturnType<typeof createClient> | null = null;

const getSupabase = () => {
  if (!supabaseInstance && supabaseUrl && supabaseKey) {
    supabaseInstance = createClient(supabaseUrl, supabaseKey, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
      },
      realtime: {
        params: {
          eventsPerSecond: 10,
        },
      },
    });
  }
  return supabaseInstance;
};

// ============================================
// TIPOS
// ============================================
interface Receita {
  id: string;
  descricao: string;
  valor: number;
  data: string;
  status: "Confirmado" | "Pendente" | "Cancelado";
  recorrencia: "mensal" | "unico";
  tipo: "receita";
  user_id?: string;
  created_at?: string;
}

interface Despesa {
  id: string;
  descricao: string;
  valor: number;
  data: string;
  categoria: "Marketing" | "Infraestrutura" | "Pessoal" | "Software" | "Impostos" | "Outros";
  recorrencia: "mensal" | "unico";
  tipo: "despesa";
  user_id?: string;
  created_at?: string;
}

interface Toast {
  id: string;
  message: string;
  type: "success" | "error" | "warning" | "info";
}

// ============================================
// UTILITÁRIOS BLINDADOS
// ============================================
const formatCurrency = (value: number | null | undefined): string => {
  try {
    if (value === null || value === undefined || isNaN(value)) return "R$ 0,00";
    return new Intl.NumberFormat("pt-BR", {
      style: "currency",
      currency: "BRL",
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(value);
  } catch (e) {
    return "R$ 0,00";
  }
};

const formatPercent = (value: number | null | undefined, decimals = 1): string => {
  try {
    if (value === null || value === undefined || isNaN(value)) return "0%";
    return `${value.toFixed(decimals).replace(".", ",")}%`;
  } catch (e) {
    return "0%";
  }
};

const safeDivide = (numerator: number, denominator: number, defaultValue = 0): number => {
  try {
    if (!denominator || denominator === 0 || isNaN(numerator) || isNaN(denominator)) {
      return defaultValue;
    }
    return numerator / denominator;
  } catch (e) {
    return defaultValue;
  }
};

const safeSum = (arr: any[], key?: string): number => {
  try {
    if (!Array.isArray(arr) || arr.length === 0) return 0;
    return arr.reduce((sum, item) => {
      const value = key ? item?.[key] : item;
      return sum + (isNaN(value) ? 0 : Number(value) || 0);
    }, 0);
  } catch (e) {
    return 0;
  }
};

const generateId = (): string => {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
};

// ============================================
// HOOK: TOASTS
// ============================================
const useToast = () => {
  const [toasts, setToasts] = useState<Toast[]>([]);

  const addToast = useCallback((message: string, type: Toast["type"] = "info") => {
    const id = generateId();
    const newToast = { id, message, type };
    setToasts((prev) => [...prev, newToast]);

    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4000);

    return id;
  }, []);

  const removeToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  return { toasts, addToast, removeToast };
};

// ============================================
// COMPONENTE: TOAST CONTAINER
// ============================================
const ToastContainer: React.FC<{ toasts: Toast[]; removeToast: (id: string) => void }> = ({
  toasts,
  removeToast,
}) => {
  const getIcon = (type: Toast["type"]) => {
    switch (type) {
      case "success":
        return CheckCircle;
      case "error":
        return X;
      case "warning":
        return AlertTriangle;
      default:
        return AlertTriangle;
    }
  };

  const getColors = (type: Toast["type"]) => {
    switch (type) {
      case "success":
        return "bg-emerald-500/20 border-emerald-500/30 text-emerald-400";
      case "error":
        return "bg-red-500/20 border-red-500/30 text-red-400";
      case "warning":
        return "bg-amber-500/20 border-amber-500/30 text-amber-400";
      default:
        return "bg-blue-500/20 border-blue-500/30 text-blue-400";
    }
  };

  return (
    <div className="fixed top-6 right-6 z-[9999] flex flex-col gap-3">
      <AnimatePresence>
        {toasts.map((toast) => {
          const Icon = getIcon(toast.type);
          return (
            <motion.div
              key={toast.id}
              initial={{ x: 100, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: 100, opacity: 0 }}
              className={`glass-strong px-4 py-3 rounded-xl border flex items-center gap-3 min-w-[300px] max-w-[400px] ${getColors(
                toast.type
              )}`}
            >
              <Icon className="w-5 h-5 flex-shrink-0" />
              <span className="text-sm font-medium text-white">{toast.message}</span>
              <button
                onClick={() => removeToast(toast.id)}
                className="ml-auto opacity-60 hover:opacity-100 transition-opacity"
              >
                <X className="w-4 h-4" />
              </button>
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
};

// ============================================
// COMPONENTE: SIDEBAR
// ============================================
const Sidebar: React.FC<{
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onLogout: () => void;
}> = ({ activeTab, setActiveTab, onLogout }) => {
  const menuItems = [
    { id: "dashboard", label: "Painel Geral", icon: LayoutDashboard },
    { id: "receitas", label: "Receitas", icon: TrendingUp },
    { id: "despesas", label: "Despesas", icon: TrendingDown },
    { id: "dre", label: "DRE", icon: FileText },
    { id: "projecoes", label: "Projeções", icon: LineChartIcon },
  ];

  return (
    <aside className="fixed left-0 top-0 h-full w-64 glass-strong z-50 flex flex-col">
      <div className="p-6 border-b border-white/10">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center">
            <BarChart3 className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1 className="font-display font-bold text-lg text-white">BG Tech</h1>
            <p className="text-xs text-gray-400">CFO Dashboard</p>
          </div>
        </div>
      </div>

      <nav className="flex-1 p-4">
        <ul className="space-y-1">
          {menuItems.map((item) => {
            const Icon = item.icon;
            return (
              <li key={item.id}>
                <button
                  onClick={() => setActiveTab(item.id)}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${
                    activeTab === item.id
                      ? "bg-blue-500/20 text-blue-400 border border-blue-500/30"
                      : "text-gray-400 hover:text-white hover:bg-white/5"
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span className="font-medium">{item.label}</span>
                  {activeTab === item.id && (
                    <motion.div
                      layoutId="activeIndicator"
                      className="ml-auto w-1.5 h-1.5 rounded-full bg-blue-500"
                    />
                  )}
                </button>
              </li>
            );
          })}
        </ul>
      </nav>

      <div className="p-4 border-t border-white/10">
        <div className="flex items-center gap-3 mb-4 px-2">
          <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-blue-500 flex items-center justify-center">
            <span className="font-display font-bold text-sm">G</span>
          </div>
          <div>
            <p className="font-medium text-sm text-white">Gustavo</p>
            <p className="text-xs text-gray-400">CFO</p>
          </div>
        </div>
        <button
          onClick={onLogout}
          className="w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-gray-400 hover:text-red-400 hover:bg-red-500/10 transition-all duration-200"
        >
          <LogOut className="w-5 h-5" />
          <span className="font-medium">Sair</span>
        </button>
      </div>
    </aside>
  );
};

// ============================================
// COMPONENTE: METRIC CARD
// ============================================
const MetricCard: React.FC<{
  title: string;
  value: string;
  subtitle?: string;
  icon: React.ElementType;
  color?: "blue" | "green" | "red" | "purple" | "amber" | "cyan";
  loading?: boolean;
  delay?: number;
}> = ({ title, value, subtitle, icon: Icon, color = "blue", loading = false, delay = 0 }) => {
  const colorMap = {
    blue: "from-blue-500/20 to-blue-600/10 border-blue-500/20 text-blue-400",
    green: "from-emerald-500/20 to-emerald-600/10 border-emerald-500/20 text-emerald-400",
    red: "from-red-500/20 to-red-600/10 border-red-500/20 text-red-400",
    purple: "from-purple-500/20 to-purple-600/10 border-purple-500/20 text-purple-400",
    amber: "from-amber-500/20 to-amber-600/10 border-amber-500/20 text-amber-400",
    cyan: "from-cyan-500/20 to-cyan-600/10 border-cyan-500/20 text-cyan-400",
  };

  const iconBgMap = {
    blue: "bg-blue-500/20 text-blue-400",
    green: "bg-emerald-500/20 text-emerald-400",
    red: "bg-red-500/20 text-red-400",
    purple: "bg-purple-500/20 text-purple-400",
    amber: "bg-amber-500/20 text-amber-400",
    cyan: "bg-cyan-500/20 text-cyan-400",
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay }}
      className={`glass rounded-2xl p-5 card-hover border bg-gradient-to-br ${colorMap[color]}`}
    >
      {loading ? (
        <div className="space-y-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/5 animate-pulse" />
            <div className="h-4 w-24 bg-white/5 rounded animate-pulse" />
          </div>
          <div className="h-8 w-32 bg-white/5 rounded animate-pulse" />
        </div>
      ) : (
        <>
          <div className="flex items-start justify-between mb-3">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${iconBgMap[color]}`}>
              <Icon className="w-5 h-5" />
            </div>
          </div>
          <h3 className="text-gray-400 text-sm font-medium mb-1">{title}</h3>
          <p className="font-display font-bold text-2xl text-white tabular-nums">{value}</p>
          {subtitle && <p className="text-xs text-gray-400 mt-1">{subtitle}</p>}
        </>
      )}
    </motion.div>
  );
};

// ============================================
// COMPONENTE: DATA TABLE
// ============================================
const DataTable: React.FC<{
  data: any[];
  columns: { key: string; label: string; render?: (value: any, item: any) => React.ReactNode }[];
  onDelete: (id: string) => Promise<void>;
  loading?: boolean;
}> = ({ data, columns, onDelete, loading = false }) => {
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const handleDelete = async (id: string) => {
    setDeletingId(id);
    try {
      await onDelete(id);
    } finally {
      setDeletingId(null);
    }
  };

  if (loading) {
    return (
      <div className="glass rounded-2xl overflow-hidden">
        <div className="p-6 space-y-4">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="flex gap-4">
              <div className="h-12 flex-1 bg-white/5 rounded animate-pulse" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (data.length === 0) {
    return (
      <div className="glass rounded-2xl p-12 text-center">
        <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center mx-auto mb-4">
          <Inbox className="w-8 h-8 text-gray-400" />
        </div>
        <h3 className="text-lg font-medium text-white mb-2">Nenhum registro encontrado</h3>
        <p className="text-gray-400">Adicione um novo item para começar</p>
      </div>
    );
  }

  return (
    <div className="glass rounded-2xl overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead>
            <tr className="border-b border-white/10">
              {columns.map((col) => (
                <th
                  key={col.key}
                  className="text-left px-6 py-4 text-xs font-semibold text-gray-400 uppercase tracking-wider"
                >
                  {col.label}
                </th>
              ))}
              <th className="text-right px-6 py-4 text-xs font-semibold text-gray-400 uppercase tracking-wider">
                Ações
              </th>
            </tr>
          </thead>
          <tbody>
            {data.map((item, index) => (
              <motion.tr
                key={item.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
                className="border-b border-white/5 hover:bg-white/5 transition-colors"
              >
                {columns.map((col) => (
                  <td key={col.key} className="px-6 py-4">
                    {col.render ? col.render(item[col.key], item) : item[col.key]}
                  </td>
                ))}
                <td className="px-6 py-4 text-right">
                  <button
                    onClick={() => handleDelete(item.id)}
                    disabled={deletingId === item.id}
                    className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg text-red-400 hover:bg-red-500/20 transition-all duration-200 disabled:opacity-50"
                  >
                    {deletingId === item.id ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Trash2 className="w-4 h-4" />
                    )}
                    <span className="text-sm font-medium">Excluir</span>
                  </button>
                </td>
              </motion.tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

// ============================================
// COMPONENTE: ADD DRAWER
// ============================================
const AddDrawer: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  type: "receita" | "despesa";
  onAdd: (item: any) => Promise<void>;
  loading: boolean;
}> = ({ isOpen, onClose, type, onAdd, loading }) => {
  const [formData, setFormData] = useState({
    descricao: "",
    valor: "",
    data: new Date().toISOString().split("T")[0],
    status: "Confirmado" as const,
    recorrencia: "mensal" as const,
    categoria: "Outros" as const,
  });

  useEffect(() => {
    if (isOpen) {
      setFormData({
        descricao: "",
        valor: "",
        data: new Date().toISOString().split("T")[0],
        status: "Confirmado",
        recorrencia: "mensal",
        categoria: "Outros",
      });
    }
  }, [isOpen]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const valor = parseFloat(formData.valor.replace(",", "."));
    if (isNaN(valor) || valor <= 0) return;

    onAdd({
      ...formData,
      valor,
      id: generateId(),
      tipo: type,
    });
  };

  const isReceita = type === "receita";

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[100]"
          />
          <motion.div
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", damping: 25, stiffness: 200 }}
            className="fixed right-0 top-0 h-full w-full max-w-md glass-strong z-[101] overflow-y-auto"
          >
            <div className="p-6">
              <div className="flex items-center justify-between mb-8">
                <div>
                  <h2 className="font-display font-bold text-xl text-white">
                    Nova {isReceita ? "Receita" : "Despesa"}
                  </h2>
                  <p className="text-sm text-gray-400 mt-1">Preencha os dados abaixo</p>
                </div>
                <button
                  onClick={onClose}
                  className="w-10 h-10 rounded-xl bg-white/5 hover:bg-white/10 flex items-center justify-center transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSubmit} className="space-y-5">
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">Descrição</label>
                  <input
                    type="text"
                    value={formData.descricao}
                    onChange={(e) => setFormData({ ...formData, descricao: e.target.value })}
                    placeholder={`Ex: ${isReceita ? "Assinatura Cliente X" : "Fatura AWS"}`}
                    className="w-full px-4 py-3 rounded-xl bg-gray-800/80 border border-white/10 text-white focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">Valor (R$)</label>
                  <input
                    type="text"
                    value={formData.valor}
                    onChange={(e) => {
                      const val = e.target.value.replace(/[^0-9.,]/g, "");
                      setFormData({ ...formData, valor: val });
                    }}
                    placeholder="0,00"
                    className="w-full px-4 py-3 rounded-xl bg-gray-800/80 border border-white/10 text-white focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">Data</label>
                  <input
                    type="date"
                    value={formData.data}
                    onChange={(e) => setFormData({ ...formData, data: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl bg-gray-800/80 border border-white/10 text-white focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                    required
                  />
                </div>

                {isReceita && (
                  <div>
                    <label className="block text-sm font-medium text-gray-400 mb-2">Status</label>
                    <select
                      value={formData.status}
                      onChange={(e) =>
                        setFormData({ ...formData, status: e.target.value as any })
                      }
                      className="w-full px-4 py-3 rounded-xl bg-gray-800/80 border border-white/10 text-white focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                    >
                      <option value="Confirmado">Confirmado</option>
                      <option value="Pendente">Pendente</option>
                      <option value="Cancelado">Cancelado</option>
                    </select>
                  </div>
                )}

                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-2">Recorrência</label>
                  <select
                    value={formData.recorrencia}
                    onChange={(e) =>
                      setFormData({ ...formData, recorrencia: e.target.value as any })
                    }
                    className="w-full px-4 py-3 rounded-xl bg-gray-800/80 border border-white/10 text-white focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                  >
                    <option value="mensal">Mensal</option>
                    <option value="unico">Único</option>
                  </select>
                </div>

                {!isReceita && (
                  <div>
                    <label className="block text-sm font-medium text-gray-400 mb-2">Categoria</label>
                    <select
                      value={formData.categoria}
                      onChange={(e) =>
                        setFormData({ ...formData, categoria: e.target.value as any })
                      }
                      className="w-full px-4 py-3 rounded-xl bg-gray-800/80 border border-white/10 text-white focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                    >
                      {["Marketing", "Infraestrutura", "Pessoal", "Software", "Impostos", "Outros"].map(
                        (cat) => (
                          <option key={cat} value={cat}>
                            {cat}
                          </option>
                        )
                      )}
                    </select>
                  </div>
                )}

                <div className="pt-4">
                  <button
                    type="submit"
                    disabled={loading || !formData.descricao || !formData.valor}
                    className={`w-full py-3.5 rounded-xl font-semibold flex items-center justify-center gap-2 transition-all ${
                      isReceita
                        ? "bg-emerald-500 hover:bg-emerald-600 text-white"
                        : "bg-red-500 hover:bg-red-600 text-white"
                    } disabled:opacity-50 disabled:cursor-not-allowed`}
                  >
                    {loading ? (
                      <>
                        <Loader2 className="w-5 h-5 animate-spin" />
                        <span>Salvando...</span>
                      </>
                    ) : (
                      <>
                        <Plus className="w-5 h-5" />
                        <span>Adicionar {isReceita ? "Receita" : "Despesa"}</span>
                      </>
                    )}
                  </button>
                </div>
              </form>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};

// ============================================
// COMPONENTE: STATUS BANNER
// ============================================
const StatusBanner: React.FC<{ status: "otimo" | "atencao" | "critico" }> = ({ status }) => {
  const statusConfig = {
    otimo: {
      icon: CheckCircle,
      title: "Status: ÓTIMO",
      subtitle: "A operação está saudável",
      color:
        "from-emerald-500/20 to-emerald-600/10 border-emerald-500/30 text-emerald-400",
    },
    atencao: {
      icon: AlertTriangle,
      title: "Status: ATENÇÃO",
      subtitle: "Monitorar indicadores",
      color: "from-amber-500/20 to-amber-600/10 border-amber-500/30 text-amber-400",
    },
    critico: {
      icon: AlertOctagon,
      title: "Status: CRÍTICO",
      subtitle: "Ação imediata necessária",
      color: "from-red-500/20 to-red-600/10 border-red-500/30 text-red-400",
    },
  };

  const config = statusConfig[status];
  const Icon = config.icon;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className={`glass rounded-2xl p-4 border bg-gradient-to-r ${config.color}`}
    >
      <div className="flex items-center gap-4">
        <div className="w-12 h-12 rounded-xl bg-white/10 flex items-center justify-center">
          <Icon className="w-6 h-6" />
        </div>
        <div>
          <h3 className="font-display font-bold text-lg">{config.title}</h3>
          <p className="text-sm opacity-80">{config.subtitle}</p>
        </div>
      </div>
    </motion.div>
  );
};

// ============================================
// VIEW: DASHBOARD
// ============================================
const DashboardView: React.FC<{
  data: { receitas: Receita[]; despesas: Despesa[] };
  loading: boolean;
  onExportPDF: () => void;
  onExportExcel: () => void;
}> = ({ data, loading, onExportPDF, onExportExcel }) => {
  const { receitas, despesas } = data;

  const totalReceitas = safeSum(
    receitas.filter((r) => r.status === "Confirmado"),
    "valor"
  );
  const totalDespesas = safeSum(despesas, "valor");
  const resultadoLiquido = totalReceitas - totalDespesas;

  const mrr = safeSum(
    receitas.filter((r) => r.status === "Confirmado" && r.recorrencia === "mensal"),
    "valor"
  );

  const burnRate = totalDespesas;
  const runway = safeDivide(resultadoLiquido, burnRate, 0);
  const margem = safeDivide(resultadoLiquido, totalReceitas, 0) * 100;

  let status: "otimo" | "atencao" | "critico" = "otimo";
  if (margem < 0) status = "critico";
  else if (margem < 15) status = "atencao";

  const chartData = [
    { name: "Jan", receitas: 45000, despesas: 32000 },
    { name: "Fev", receitas: 52000, despesas: 35000 },
    { name: "Mar", receitas: 48000, despesas: 33000 },
    { name: "Abr", receitas: 61000, despesas: 38000 },
    { name: "Mai", receitas: 58000, despesas: 36000 },
    { name: "Jun", receitas: 65000, despesas: 40000 },
  ];

  const pieData = [
    { name: "Marketing", value: 15000, color: "#bf5af2" },
    { name: "Infraestrutura", value: 12000, color: "#0a84ff" },
    { name: "Pessoal", value: 8000, color: "#30d158" },
    { name: "Software", value: 5000, color: "#ff9f0a" },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="font-display font-bold text-2xl text-white">Painel Geral</h2>
        <div className="flex gap-2">
          <button
            onClick={onExportPDF}
            className="flex items-center gap-2 px-4 py-2 bg-red-500/20 hover:bg-red-500/30 text-red-400 rounded-lg transition-colors"
          >
            <FileIcon className="w-4 h-4" />
            Exportar PDF
          </button>
          <button
            onClick={onExportExcel}
            className="flex items-center gap-2 px-4 py-2 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-400 rounded-lg transition-colors"
          >
            <FileSpreadsheet className="w-4 h-4" />
            Exportar Excel
          </button>
        </div>
      </div>

      <StatusBanner status={status} />

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          title="MRR"
          value={formatCurrency(mrr)}
          subtitle="Receita Recorrente Mensal"
          icon={Repeat}
          color="purple"
          loading={loading}
          delay={0}
        />
        <MetricCard
          title="Burn Rate"
          value={formatCurrency(burnRate)}
          subtitle="Sangria Mensal Total"
          icon={Flame}
          color="red"
          loading={loading}
          delay={0.1}
        />
        <MetricCard
          title="Resultado Líquido"
          value={formatCurrency(resultadoLiquido)}
          subtitle={resultadoLiquido >= 0 ? "Lucro" : "Prejuízo"}
          icon={Wallet}
          color={resultadoLiquido >= 0 ? "green" : "red"}
          loading={loading}
          delay={0.2}
        />
        <MetricCard
          title="Margem"
          value={formatPercent(margem)}
          subtitle="Rentabilidade"
          icon={Percent}
          color={margem >= 20 ? "green" : margem >= 10 ? "amber" : "red"}
          loading={loading}
          delay={0.3}
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <MetricCard
          title="Caixa Disponível"
          value={formatCurrency(resultadoLiquido)}
          subtitle="Saldo em Conta"
          icon={Banknote}
          color="cyan"
          loading={loading}
          delay={0.4}
        />
        <MetricCard
          title="Runway"
          value={`${runway.toFixed(1)}x`}
          subtitle="Meses de Reserva"
          icon={Timer}
          color={runway >= 3 ? "green" : runway >= 1 ? "amber" : "red"}
          loading={loading}
          delay={0.5}
        />
        <MetricCard
          title="Total Receitas"
          value={formatCurrency(totalReceitas)}
          subtitle={`${receitas.length} transações`}
          icon={ArrowUpCircle}
          color="green"
          loading={loading}
          delay={0.6}
        />
        <MetricCard
          title="Total Despesas"
          value={formatCurrency(totalDespesas)}
          subtitle={`${despesas.length} transações`}
          icon={ArrowDownCircle}
          color="red"
          loading={loading}
          delay={0.7}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
          className="glass rounded-2xl p-6"
        >
          <h3 className="font-display font-bold text-lg mb-4">Fluxo de Caixa</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorReceitas" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#30d158" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#30d158" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="colorDespesas" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#ff453a" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#ff453a" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                <XAxis dataKey="name" stroke="rgba(255,255,255,0.5)" />
                <YAxis stroke="rgba(255,255,255,0.5)" />
                <Tooltip
                  contentStyle={{
                    background: "#1c1c1e",
                    border: "1px solid rgba(255,255,255,0.1)",
                    borderRadius: "8px",
                  }}
                  formatter={(value: number) => formatCurrency(value)}
                />
                <Area
                  type="monotone"
                  dataKey="receitas"
                  stroke="#30d158"
                  fillOpacity={1}
                  fill="url(#colorReceitas)"
                />
                <Area
                  type="monotone"
                  dataKey="despesas"
                  stroke="#ff453a"
                  fillOpacity={1}
                  fill="url(#colorDespesas)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.9 }}
          className="glass rounded-2xl p-6"
        >
          <h3 className="font-display font-bold text-lg mb-4">Distribuição de Despesas</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    background: "#1c1c1e",
                    border: "1px solid rgba(255,255,255,0.1)",
                    borderRadius: "8px",
                  }}
                  formatter={(value: number) => formatCurrency(value)}
                />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

// ============================================
// VIEW: RECEITAS
// ============================================
const ReceitasView: React.FC<{
  data: Receita[];
  onAdd: (item: any) => Promise<void>;
  onDelete: (id: string) => Promise<void>;
  loading: boolean;
}> = ({ data, onAdd, onDelete, loading }) => {
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [addLoading, setAddLoading] = useState(false);

  const handleAdd = async (item: any) => {
    setAddLoading(true);
    try {
      await onAdd(item);
      setDrawerOpen(false);
    } finally {
      setAddLoading(false);
    }
  };

  const columns = [
    { key: "descricao", label: "Descrição" },
    {
      key: "valor",
      label: "Valor",
      render: (v: number) => <span className="font-medium text-emerald-400">{formatCurrency(v)}</span>,
    },
    {
      key: "data",
      label: "Data",
      render: (v: string) => new Date(v).toLocaleDateString("pt-BR"),
    },
    {
      key: "status",
      label: "Status",
      render: (v: string) => (
        <span
          className={`px-2 py-1 rounded-full text-xs font-medium ${
            v === "Confirmado"
              ? "bg-emerald-500/20 text-emerald-400"
              : v === "Pendente"
              ? "bg-amber-500/20 text-amber-400"
              : "bg-red-500/20 text-red-400"
          }`}
        >
          {v}
        </span>
      ),
    },
    {
      key: "recorrencia",
      label: "Recorrência",
      render: (v: string) => (
        <span className="flex items-center gap-1 text-sm">
          {v === "mensal" ? <Repeat className="w-4 h-4" /> : <Zap className="w-4 h-4" />}
          {v === "mensal" ? "Mensal" : "Único"}
        </span>
      ),
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-display font-bold text-2xl text-white">Receitas</h2>
          <p className="text-gray-400">Gerencie todas as entradas financeiras</p>
        </div>
        <button
          onClick={() => setDrawerOpen(true)}
          className="flex items-center gap-2 px-5 py-2.5 bg-emerald-500 hover:bg-emerald-600 text-white rounded-xl font-medium transition-all"
        >
          <Plus className="w-5 h-5" />
          Nova Receita
        </button>
      </div>

      <DataTable data={data} columns={columns} onDelete={onDelete} loading={loading} />

      <AddDrawer isOpen={drawerOpen} onClose={() => setDrawerOpen(false)} type="receita" onAdd={handleAdd} loading={addLoading} />
    </div>
  );
};

// ============================================
// VIEW: DESPESAS
// ============================================
const DespesasView: React.FC<{
  data: Despesa[];
  onAdd: (item: any) => Promise<void>;
  onDelete: (id: string) => Promise<void>;
  loading: boolean;
}> = ({ data, onAdd, onDelete, loading }) => {
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [addLoading, setAddLoading] = useState(false);

  const handleAdd = async (item: any) => {
    setAddLoading(true);
    try {
      await onAdd(item);
      setDrawerOpen(false);
    } finally {
      setAddLoading(false);
    }
  };

  const columns = [
    { key: "descricao", label: "Descrição" },
    {
      key: "valor",
      label: "Valor",
      render: (v: number) => <span className="font-medium text-red-400">{formatCurrency(v)}</span>,
    },
    {
      key: "data",
      label: "Data",
      render: (v: string) => new Date(v).toLocaleDateString("pt-BR"),
    },
    { key: "categoria", label: "Categoria" },
    {
      key: "recorrencia",
      label: "Recorrência",
      render: (v: string) => (
        <span className="flex items-center gap-1 text-sm">
          {v === "mensal" ? <Repeat className="w-4 h-4" /> : <Zap className="w-4 h-4" />}
          {v === "mensal" ? "Mensal" : "Único"}
        </span>
      ),
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-display font-bold text-2xl text-white">Despesas</h2>
          <p className="text-gray-400">Gerencie todas as saídas financeiras</p>
        </div>
        <button
          onClick={() => setDrawerOpen(true)}
          className="flex items-center gap-2 px-5 py-2.5 bg-red-500 hover:bg-red-600 text-white rounded-xl font-medium transition-all"
        >
          <Plus className="w-5 h-5" />
          Nova Despesa
        </button>
      </div>

      <DataTable data={data} columns={columns} onDelete={onDelete} loading={loading} />

      <AddDrawer isOpen={drawerOpen} onClose={() => setDrawerOpen(false)} type="despesa" onAdd={handleAdd} loading={addLoading} />
    </div>
  );
};

// ============================================
// VIEW: DRE
// ============================================
const DREView: React.FC<{
  data: { receitas: Receita[]; despesas: Despesa[] };
  loading: boolean;
}> = ({ data, loading }) => {
  const { receitas, despesas } = data;

  const receitaBruta = safeSum(receitas.filter((r) => r.status === "Confirmado"), "valor");
  const impostos = safeSum(despesas.filter((d) => d.categoria === "Impostos"), "valor");
  const receitaLiquida = receitaBruta - impostos;

  const despesasOperacionais = safeSum(
    despesas.filter((d) => d.categoria !== "Impostos"),
    "valor"
  );

  const lucroBruto = receitaLiquida - despesasOperacionais;
  const margemBruta = safeDivide(lucroBruto, receitaLiquida, 0) * 100;

  const ebitda = lucroBruto;
  const margemEbitda = safeDivide(ebitda, receitaLiquida, 0) * 100;

  const resultadoLiquido = ebitda - impostos;
  const margemLiquida = safeDivide(resultadoLiquido, receitaLiquida, 0) * 100;

  const dreData = [
    { descricao: "RECEITA BRUTA", valor: receitaBruta, tipo: "receita", nivel: 0 },
    { descricao: "(-) Impostos", valor: impostos, tipo: "despesa", nivel: 1 },
    { descricao: "(=) RECEITA LÍQUIDA", valor: receitaLiquida, tipo: "total", nivel: 0 },
    { descricao: "(-) Despesas Operacionais", valor: despesasOperacionais, tipo: "despesa", nivel: 1 },
    { descricao: "(=) LUCRO BRUTO", valor: lucroBruto, tipo: "total", nivel: 0 },
    { descricao: "    Margem Bruta", valor: `${margemBruta.toFixed(1)}%`, tipo: "percent", nivel: 1 },
    { descricao: "(=) EBITDA", valor: ebitda, tipo: "total", nivel: 0 },
    { descricao: "    Margem EBITDA", valor: `${margemEbitda.toFixed(1)}%`, tipo: "percent", nivel: 1 },
    { descricao: "(-) Impostos", valor: impostos, tipo: "despesa", nivel: 1 },
    { descricao: "(=) RESULTADO LÍQUIDO", valor: resultadoLiquido, tipo: "final", nivel: 0 },
    { descricao: "    Margem Líquida", valor: `${margemLiquida.toFixed(1)}%`, tipo: "percent", nivel: 1 },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="font-display font-bold text-2xl text-white">DRE - Demonstração do Resultado</h2>
        <p className="text-gray-400">Análise completa do resultado do exercício</p>
      </div>

      {loading ? (
        <div className="glass rounded-2xl p-8 space-y-4">
          {[1, 2, 3, 4, 5].map((i) => (
            <div key={i} className="h-12 bg-white/5 rounded animate-pulse" />
          ))}
        </div>
      ) : (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="glass rounded-2xl overflow-hidden">
          <table className="w-full">
            <thead>
              <tr className="border-b border-white/10">
                <th className="text-left px-6 py-4 text-xs font-semibold text-gray-400 uppercase">Descrição</th>
                <th className="text-right px-6 py-4 text-xs font-semibold text-gray-400 uppercase">Valor</th>
              </tr>
            </thead>
            <tbody>
              {dreData.map((item, index) => (
                <tr
                  key={index}
                  className={`border-b border-white/5 ${
                    item.tipo === "total" ? "bg-white/5" : item.tipo === "final" ? "bg-emerald-500/10" : ""
                  }`}
                >
                  <td
                    className={`px-6 py-4 ${item.nivel === 0 ? "font-display font-bold" : "font-medium"} ${
                      item.tipo === "receita"
                        ? "text-emerald-400"
                        : item.tipo === "despesa"
                        ? "text-red-400"
                        : item.tipo === "total"
                        ? "text-white"
                        : item.tipo === "final"
                        ? "text-emerald-400 font-bold"
                        : "text-gray-400"
                    }`}
                    style={{ paddingLeft: `${24 + item.nivel * 24}px` }}
                  >
                    {item.descricao}
                  </td>
                  <td
                    className={`text-right px-6 py-4 font-mono ${
                      item.tipo === "receita"
                        ? "text-emerald-400"
                        : item.tipo === "despesa"
                        ? "text-red-400"
                        : item.tipo === "total"
                        ? "text-white font-bold"
                        : item.tipo === "final"
                        ? "text-emerald-400 font-bold text-lg"
                        : "text-gray-400"
                    }`}
                  >
                    {typeof item.valor === "number" ? formatCurrency(item.valor) : item.valor}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </motion.div>
      )}
    </div>
  );
};

// ============================================
// VIEW: PROJEÇÕES
// ============================================
const ProjecoesView: React.FC<{
  data: { receitas: Receita[]; despesas: Despesa[] };
  loading: boolean;
}> = ({ data, loading }) => {
  const { receitas, despesas } = data;

  const mrr = safeSum(
    receitas.filter((r) => r.status === "Confirmado" && r.recorrencia === "mensal"),
    "valor"
  );

  const burnRate = safeSum(despesas, "valor");
  const caixaAtual = mrr - burnRate;

  const projecoes = [];
  let caixaProjetado = caixaAtual;

  for (let i = 1; i <= 12; i++) {
    caixaProjetado = caixaProjetado + mrr - burnRate;
    projecoes.push({
      mes: `M${i}`,
      caixa: caixaProjetado,
      receitas: mrr * i,
      despesas: burnRate * i,
    });
  }

  const crescimento = 10;

  return (
    <div className="space-y-6">
      <div>
        <h2 className="font-display font-bold text-2xl text-white">Projeções Financeiras</h2>
        <p className="text-gray-400">Forecast para os próximos 12 meses</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <MetricCard title="MRR Atual" value={formatCurrency(mrr)} subtitle="Base para projeções" icon={TrendingUp} color="green" loading={loading} />
        <MetricCard title="Burn Rate" value={formatCurrency(burnRate)} subtitle="Gasto mensal" icon={Flame} color="red" loading={loading} />
        <MetricCard title="Crescimento Projetado" value={`+${crescimento}%`} subtitle="Ao mês" icon={Rocket} color="purple" loading={loading} />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="glass rounded-2xl p-6"
      >
        <h3 className="font-display font-bold text-lg mb-4">Projeção de Caixa - 12 Meses</h3>
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={projecoes}>
              <defs>
                <linearGradient id="colorCaixa" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#0a84ff" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#0a84ff" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
              <XAxis dataKey="mes" stroke="rgba(255,255,255,0.5)" />
              <YAxis stroke="rgba(255,255,255,0.5)" />
              <Tooltip
                contentStyle={{
                  background: "#1c1c1e",
                  border: "1px solid rgba(255,255,255,0.1)",
                  borderRadius: "8px",
                }}
                formatter={(value: number) => formatCurrency(value)}
              />
              <Area type="monotone" dataKey="caixa" stroke="#0a84ff" fillOpacity={1} fill="url(#colorCaixa)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
        className="glass rounded-2xl overflow-hidden"
      >
        <table className="w-full">
          <thead>
            <tr className="border-b border-white/10">
              <th className="text-left px-6 py-4 text-xs font-semibold text-gray-400 uppercase">Mês</th>
              <th className="text-right px-6 py-4 text-xs font-semibold text-gray-400 uppercase">Receitas Acum.</th>
              <th className="text-right px-6 py-4 text-xs font-semibold text-gray-400 uppercase">Despesas Acum.</th>
              <th className="text-right px-6 py-4 text-xs font-semibold text-gray-400 uppercase">Caixa Projetado</th>
            </tr>
          </thead>
          <tbody>
            {projecoes.slice(0, 6).map((p, i) => (
              <tr key={i} className="border-b border-white/5">
                <td className="px-6 py-4 font-medium">{p.mes}</td>
                <td className="text-right px-6 py-4 text-emerald-400">{formatCurrency(p.receitas)}</td>
                <td className="text-right px-6 py-4 text-red-400">{formatCurrency(p.despesas)}</td>
                <td className={`text-right px-6 py-4 font-bold ${p.caixa >= 0 ? "text-emerald-400" : "text-red-400"}`}>
                  {formatCurrency(p.caixa)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </motion.div>
    </div>
  );
};

// ============================================
// COMPONENTE: LOGIN
// ============================================
const LoginScreen: React.FC<{ onLogin: () => void; addToast: (msg: string, type: any) => void }> = ({
  onLogin,
  addToast,
}) => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    setTimeout(() => {
      if (username === "gustavo" && password === "admin2024") {
        onLogin();
        addToast("Bem-vindo, Gustavo! 🚀", "success");
      } else {
        setError("Credenciais inválidas. Tente: gustavo / admin2024");
      }
      setLoading(false);
    }, 800);
  };

  return (
    <div className="min-h-screen flex items-center justify-center gradient-mesh p-4">
      <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }} className="w-full max-w-md">
        <div className="glass-strong rounded-3xl p-8 border border-white/10">
          <div className="text-center mb-8">
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center mx-auto mb-4">
              <BarChart3 className="w-8 h-8 text-white" />
            </div>
            <h1 className="font-display font-bold text-2xl text-white mb-2">BG Tech</h1>
            <p className="text-gray-400">CFO Dashboard</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            {error && (
              <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} className="p-3 rounded-xl bg-red-500/20 border border-red-500/30 text-red-400 text-sm text-center">
                {error}
              </motion.div>
            )}

            <div>
              <label className="block text-sm font-medium text-gray-400 mb-2">Usuário</label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="gustavo"
                className="w-full px-4 py-3.5 rounded-xl bg-gray-800/80 border border-white/10 text-white focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-400 mb-2">Senha</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full px-4 py-3.5 rounded-xl bg-gray-800/80 border border-white/10 text-white focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20"
                required
              />
            </div>

            <button
              type="submit"
              disabled={loading || !username || !password}
              className="w-full py-3.5 bg-blue-500 hover:bg-blue-600 text-white rounded-xl font-semibold transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {loading ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  <span>Entrando...</span>
                </>
              ) : (
                <>
                  <LogOut className="w-5 h-5" />
                  <span>Entrar</span>
                </>
              )}
            </button>
          </form>

          <p className="text-center text-xs text-gray-400 mt-6">Credenciais: gustavo / admin2024</p>
        </div>
      </motion.div>
    </div>
  );
};

// ============================================
// APP PRINCIPAL
// ============================================
export default function CFODashboard() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [activeTab, setActiveTab] = useState("dashboard");
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<{ receitas: Receita[]; despesas: Despesa[] }>({
    receitas: [],
    despesas: [],
  });
  const [isOnline, setIsOnline] = useState(false);
  const { toasts, addToast, removeToast } = useToast();

  const realtimeChannels = useRef<any[]>([]);
  const isMounted = useRef(true);

  // ============================================
  // FUNÇÕES DE EXPORTAÇÃO
  // ============================================
  const exportToPDF = useCallback(() => {
    try {
      const doc = new jsPDF();
      
      // Título
      doc.setFontSize(20);
      doc.text("CFO Dashboard - Relatório Financeiro", 14, 20);
      
      doc.setFontSize(12);
      doc.text(`Data: ${new Date().toLocaleDateString("pt-BR")}`, 14, 30);
      
      // Resumo
      const totalReceitas = safeSum(data.receitas.filter((r) => r.status === "Confirmado"), "valor");
      const totalDespesas = safeSum(data.despesas, "valor");
      const resultado = totalReceitas - totalDespesas;
      
      doc.text(`Total Receitas: ${formatCurrency(totalReceitas)}`, 14, 45);
      doc.text(`Total Despesas: ${formatCurrency(totalDespesas)}`, 14, 52);
      doc.text(`Resultado: ${formatCurrency(resultado)}`, 14, 59);
      
      // Tabela de Receitas
      doc.text("Receitas:", 14, 75);
      autoTable(doc, {
        startY: 80,
        head: [["Descrição", "Valor", "Data", "Status"]],
        body: data.receitas.map((r) => [
          r.descricao,
          formatCurrency(r.valor),
          new Date(r.data).toLocaleDateString("pt-BR"),
          r.status,
        ]),
      });
      
      // Tabela de Despesas
      const finalY = (doc as any).lastAutoTable?.finalY || 120;
      doc.text("Despesas:", 14, finalY + 15);
      autoTable(doc, {
        startY: finalY + 20,
        head: [["Descrição", "Valor", "Data", "Categoria"]],
        body: data.despesas.map((d) => [
          d.descricao,
          formatCurrency(d.valor),
          new Date(d.data).toLocaleDateString("pt-BR"),
          d.categoria,
        ]),
      });
      
      doc.save(`cfo-dashboard-${new Date().toISOString().split("T")[0]}.pdf`);
      addToast("PDF exportado com sucesso!", "success");
    } catch (error) {
      console.error("Erro ao exportar PDF:", error);
      addToast("Erro ao exportar PDF", "error");
    }
  }, [data, addToast]);

  const exportToExcel = useCallback(() => {
    try {
      const wb = XLSX.utils.book_new();
      
      // Aba Receitas
      const wsReceitas = XLSX.utils.json_to_sheet(
        data.receitas.map((r) => ({
          Descrição: r.descricao,
          Valor: r.valor,
          Data: r.data,
          Status: r.status,
          Recorrência: r.recorrencia,
        }))
      );
      XLSX.utils.book_append_sheet(wb, wsReceitas, "Receitas");
      
      // Aba Despesas
      const wsDespesas = XLSX.utils.json_to_sheet(
        data.despesas.map((d) => ({
          Descrição: d.descricao,
          Valor: d.valor,
          Data: d.data,
          Categoria: d.categoria,
          Recorrência: d.recorrencia,
        }))
      );
      XLSX.utils.book_append_sheet(wb, wsDespesas, "Despesas");
      
      // Aba Resumo
      const totalReceitas = safeSum(data.receitas.filter((r) => r.status === "Confirmado"), "valor");
      const totalDespesas = safeSum(data.despesas, "valor");
      const mrr = safeSum(
        data.receitas.filter((r) => r.status === "Confirmado" && r.recorrencia === "mensal"),
        "valor"
      );
      
      const wsResumo = XLSX.utils.json_to_sheet([
        { Métrica: "Total Receitas", Valor: totalReceitas },
        { Métrica: "Total Despesas", Valor: totalDespesas },
        { Métrica: "Resultado Líquido", Valor: totalReceitas - totalDespesas },
        { Métrica: "MRR", Valor: mrr },
        { Métrica: "Burn Rate", Valor: totalDespesas },
      ]);
      XLSX.utils.book_append_sheet(wb, wsResumo, "Resumo");
      
      XLSX.writeFile(wb, `cfo-dashboard-${new Date().toISOString().split("T")[0]}.xlsx`);
      addToast("Excel exportado com sucesso!", "success");
    } catch (error) {
      console.error("Erro ao exportar Excel:", error);
      addToast("Erro ao exportar Excel", "error");
    }
  }, [data, addToast]);

  // ============================================
  // CARREGAR DADOS DO SUPABASE
  // ============================================
  const loadData = useCallback(async () => {
    if (!isMounted.current) return;
    
    try {
      setLoading(true);
      const supabase = getSupabase();
      
      if (!supabase) {
        // Fallback: carregar do localStorage
        const saved = localStorage.getItem("cfo-dashboard-data");
        if (saved) {
          setData(JSON.parse(saved));
        }
        setIsOnline(false);
        return;
      }

      // Carregar receitas
      const { data: receitasData, error: receitasError } = await supabase
        .from("receitas")
        .select("*")
        .order("created_at", { ascending: false });

      if (receitasError) throw receitasError;

      // Carregar despesas
      const { data: despesasData, error: despesasError } = await supabase
        .from("despesas")
        .select("*")
        .order("created_at", { ascending: false });

      if (despesasError) throw despesasError;

      if (isMounted.current) {
        setData({
          receitas: receitasData || [],
          despesas: despesasData || [],
        });
        setIsOnline(true);
      }
    } catch (error) {
      console.error("Erro ao carregar dados:", error);
      addToast("Erro ao sincronizar com o servidor", "error");
      
      // Fallback para localStorage
      const saved = localStorage.getItem("cfo-dashboard-data");
      if (saved) {
        setData(JSON.parse(saved));
      }
      setIsOnline(false);
    } finally {
      if (isMounted.current) {
        setLoading(false);
      }
    }
  }, [addToast]);

  // ============================================
  // REALTIME SYNC
  // ============================================
  useEffect(() => {
    isMounted.current = true;
    
    // Carregar dados iniciais
    loadData();

    const supabase = getSupabase();
    if (!supabase) return;

    // Configurar canais realtime
    try {
      // Canal para receitas
      const receitasChannel = supabase
        .channel("receitas-changes")
        .on(
          "postgres_changes",
          { event: "*", schema: "public", table: "receitas" },
          (payload) => {
            if (!isMounted.current) return;
            
            setData((prev) => {
              let newReceitas = [...prev.receitas];
              
              if (payload.eventType === "INSERT") {
                newReceitas = [payload.new as Receita, ...newReceitas];
                addToast("Nova receita adicionada!", "success");
              } else if (payload.eventType === "UPDATE") {
                const index = newReceitas.findIndex((r) => r.id === payload.new.id);
                if (index !== -1) {
                  newReceitas[index] = payload.new as Receita;
                }
              } else if (payload.eventType === "DELETE") {
                newReceitas = newReceitas.filter((r) => r.id !== payload.old.id);
              }
              
              return { ...prev, receitas: newReceitas };
            });
          }
        )
        .subscribe();

      // Canal para despesas
      const despesasChannel = supabase
        .channel("despesas-changes")
        .on(
          "postgres_changes",
          { event: "*", schema: "public", table: "despesas" },
          (payload) => {
            if (!isMounted.current) return;
            
            setData((prev) => {
              let newDespesas = [...prev.despesas];
              
              if (payload.eventType === "INSERT") {
                newDespesas = [payload.new as Despesa, ...newDespesas];
                addToast("Nova despesa adicionada!", "success");
              } else if (payload.eventType === "UPDATE") {
                const index = newDespesas.findIndex((d) => d.id === payload.new.id);
                if (index !== -1) {
                  newDespesas[index] = payload.new as Despesa;
                }
              } else if (payload.eventType === "DELETE") {
                newDespesas = newDespesas.filter((d) => d.id !== payload.old.id);
              }
              
              return { ...prev, despesas: newDespesas };
            });
          }
        )
        .subscribe();

      realtimeChannels.current = [receitasChannel, despesasChannel];
    } catch (error) {
      console.error("Erro ao configurar realtime:", error);
    }

    return () => {
      isMounted.current = false;
      // Limpar canais
      realtimeChannels.current.forEach((channel) => {
        try {
          supabase?.removeChannel(channel);
        } catch (e) {
          console.error("Erro ao remover canal:", e);
        }
      });
    };
  }, [loadData, addToast]);

  // ============================================
  // PERSISTÊNCIA LOCAL (BACKUP)
  // ============================================
  useEffect(() => {
    try {
      localStorage.setItem("cfo-dashboard-data", JSON.stringify(data));
    } catch (e) {
      console.error("Erro ao salvar no localStorage:", e);
    }
  }, [data]);

  // ============================================
  // CRUD OPERATIONS
  // ============================================
  const handleAddReceita = useCallback(
    async (item: Omit<Receita, "id" | "user_id" | "created_at">) => {
      try {
        const supabase = getSupabase();
        
        if (supabase) {
          const { error } = await supabase.from("receitas").insert([item]);
          if (error) throw error;
        } else {
          // Modo offline
          setData((prev) => ({
            ...prev,
            receitas: [{ ...item, id: generateId() } as Receita, ...prev.receitas],
          }));
        }
        
        addToast("Receita adicionada com sucesso!", "success");
        return true;
      } catch (error) {
        console.error("Erro ao adicionar receita:", error);
        addToast("Erro ao adicionar receita", "error");
        throw error;
      }
    },
    [addToast]
  );

  const handleAddDespesa = useCallback(
    async (item: Omit<Despesa, "id" | "user_id" | "created_at">) => {
      try {
        const supabase = getSupabase();
        
        if (supabase) {
          const { error } = await supabase.from("despesas").insert([item]);
          if (error) throw error;
        } else {
          setData((prev) => ({
            ...prev,
            despesas: [{ ...item, id: generateId() } as Despesa, ...prev.despesas],
          }));
        }
        
        addToast("Despesa adicionada com sucesso!", "success");
        return true;
      } catch (error) {
        console.error("Erro ao adicionar despesa:", error);
        addToast("Erro ao adicionar despesa", "error");
        throw error;
      }
    },
    [addToast]
  );

  const handleDeleteReceita = useCallback(
    async (id: string) => {
      try {
        const supabase = getSupabase();
        
        if (supabase) {
          const { error } = await supabase.from("receitas").delete().eq("id", id);
          if (error) throw error;
        } else {
          setData((prev) => ({
            ...prev,
            receitas: prev.receitas.filter((r) => r.id !== id),
          }));
        }
        
        addToast("Receita excluída com sucesso!", "success");
        return true;
      } catch (error) {
        console.error("Erro ao excluir receita:", error);
        addToast("Erro ao excluir receita", "error");
        throw error;
      }
    },
    [addToast]
  );

  const handleDeleteDespesa = useCallback(
    async (id: string) => {
      try {
        const supabase = getSupabase();
        
        if (supabase) {
          const { error } = await supabase.from("despesas").delete().eq("id", id);
          if (error) throw error;
        } else {
          setData((prev) => ({
            ...prev,
            despesas: prev.despesas.filter((d) => d.id !== id),
          }));
        }
        
        addToast("Despesa excluída com sucesso!", "success");
        return true;
      } catch (error) {
        console.error("Erro ao excluir despesa:", error);
        addToast("Erro ao excluir despesa", "error");
        throw error;
      }
    },
    [addToast]
  );

  const handleLogin = () => {
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setActiveTab("dashboard");
    addToast("Logout realizado com sucesso", "info");
  };

  // ============================================
  // RENDER
  // ============================================
  if (!isAuthenticated) {
    return (
      <>
        <LoginScreen onLogin={handleLogin} addToast={addToast} />
        <ToastContainer toasts={toasts} removeToast={removeToast} />
      </>
    );
  }

  return (
    <div className="min-h-screen bg-black">
      {/* Background gradient */}
      <div className="fixed inset-0 gradient-mesh pointer-events-none" />
      
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} onLogout={handleLogout} />

      <main className="ml-64 min-h-screen relative">
        {/* Header */}
        <header className="sticky top-0 z-40 glass-strong border-b border-white/10">
          <div className="px-8 py-5">
            <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }}>
              <h1 className="font-display font-bold text-2xl text-white">
                Bem vindo, gustavo..{" "}
                <span className="bg-gradient-to-r from-blue-500 via-purple-500 to-blue-500 bg-clip-text text-transparent">
                  o cfo mais foda da porra toda
                </span>{" "}
                <span className="inline-block animate-bounce">🚀</span>
              </h1>
              <div className="flex items-center gap-4 mt-1">
                <p className="text-gray-400">
                  {new Date().toLocaleDateString("pt-BR", {
                    weekday: "long",
                    year: "numeric",
                    month: "long",
                    day: "numeric",
                  })}
                </p>
                {isOnline && (
                  <span className="flex items-center gap-1 text-xs text-emerald-400">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                    Online
                  </span>
                )}
              </div>
            </motion.div>
          </div>
        </header>

        {/* Content */}
        <div className="p-8">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
            >
              {activeTab === "dashboard" && (
                <DashboardView
                  data={data}
                  loading={loading}
                  onExportPDF={exportToPDF}
                  onExportExcel={exportToExcel}
                />
              )}
              {activeTab === "receitas" && (
                <ReceitasView
                  data={data.receitas}
                  onAdd={handleAddReceita}
                  onDelete={handleDeleteReceita}
                  loading={loading}
                />
              )}
              {activeTab === "despesas" && (
                <DespesasView
                  data={data.despesas}
                  onAdd={handleAddDespesa}
                  onDelete={handleDeleteDespesa}
                  loading={loading}
                />
              )}
              {activeTab === "dre" && <DREView data={data} loading={loading} />}
              {activeTab === "projecoes" && <ProjecoesView data={data} loading={loading} />}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>

      <ToastContainer toasts={toasts} removeToast={removeToast} />
    </div>
  );
}
