-- ============================================
-- CFO DASHBOARD - SUPABASE SCHEMA COMPLETO
-- ============================================

-- Habilitar extensão UUID
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================
-- TABELA: RECEITAS
-- ============================================
CREATE TABLE IF NOT EXISTS public.receitas (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    descricao TEXT NOT NULL,
    valor DECIMAL(12,2) NOT NULL CHECK (valor >= 0),
    data DATE NOT NULL DEFAULT CURRENT_DATE,
    status TEXT NOT NULL DEFAULT 'Confirmado' CHECK (status IN ('Confirmado', 'Pendente', 'Cancelado')),
    recorrencia TEXT NOT NULL DEFAULT 'mensal' CHECK (recorrencia IN ('mensal', 'unico')),
    tipo TEXT NOT NULL DEFAULT 'receita',
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Comentários
COMMENT ON TABLE public.receitas IS 'Tabela de receitas do CFO Dashboard';
COMMENT ON COLUMN public.receitas.valor IS 'Valor em Reais (R$)';
COMMENT ON COLUMN public.receitas.status IS 'Confirmado, Pendente ou Cancelado';
COMMENT ON COLUMN public.receitas.recorrencia IS 'mensal ou unico';

-- ============================================
-- TABELA: DESPESAS
-- ============================================
CREATE TABLE IF NOT EXISTS public.despesas (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    descricao TEXT NOT NULL,
    valor DECIMAL(12,2) NOT NULL CHECK (valor >= 0),
    data DATE NOT NULL DEFAULT CURRENT_DATE,
    categoria TEXT NOT NULL DEFAULT 'Outros' CHECK (categoria IN ('Marketing', 'Infraestrutura', 'Pessoal', 'Software', 'Impostos', 'Outros')),
    recorrencia TEXT NOT NULL DEFAULT 'mensal' CHECK (recorrencia IN ('mensal', 'unico')),
    tipo TEXT NOT NULL DEFAULT 'despesa',
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Comentários
COMMENT ON TABLE public.despesas IS 'Tabela de despesas do CFO Dashboard';
COMMENT ON COLUMN public.despesas.categoria IS 'Categoria da despesa';

-- ============================================
-- ÍNDICES PARA PERFORMANCE
-- ============================================
CREATE INDEX IF NOT EXISTS idx_receitas_user_id ON public.receitas(user_id);
CREATE INDEX IF NOT EXISTS idx_receitas_data ON public.receitas(data);
CREATE INDEX IF NOT EXISTS idx_receitas_status ON public.receitas(status);
CREATE INDEX IF NOT EXISTS idx_receitas_recorrencia ON public.receitas(recorrencia);

CREATE INDEX IF NOT EXISTS idx_despesas_user_id ON public.despesas(user_id);
CREATE INDEX IF NOT EXISTS idx_despesas_data ON public.despesas(data);
CREATE INDEX IF NOT EXISTS idx_despesas_categoria ON public.despesas(categoria);

-- ============================================
-- ROW LEVEL SECURITY (RLS) - POLÍTICAS
-- ============================================

-- Habilitar RLS nas tabelas
ALTER TABLE public.receitas ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.despesas ENABLE ROW LEVEL SECURITY;

-- Política: Usuários só veem seus próprios dados (RECEITAS)
CREATE POLICY "Usuários veem apenas suas receitas" 
ON public.receitas 
FOR ALL 
TO authenticated 
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

-- Política: Usuários só veem seus próprios dados (DESPESAS)
CREATE POLICY "Usuários veem apenas suas despesas" 
ON public.despesas 
FOR ALL 
TO authenticated 
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

-- Política: Permitir INSERT para usuários autenticados (RECEITAS)
CREATE POLICY "Permitir insert em receitas" 
ON public.receitas 
FOR INSERT 
TO authenticated 
WITH CHECK (auth.uid() = user_id);

-- Política: Permitir INSERT para usuários autenticados (DESPESAS)
CREATE POLICY "Permitir insert em despesas" 
ON public.despesas 
FOR INSERT 
TO authenticated 
WITH CHECK (auth.uid() = user_id);

-- ============================================
-- FUNÇÃO: ATUALIZAR updated_at
-- ============================================
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Triggers para atualizar updated_at
DROP TRIGGER IF EXISTS update_receitas_updated_at ON public.receitas;
CREATE TRIGGER update_receitas_updated_at
    BEFORE UPDATE ON public.receitas
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

DROP TRIGGER IF EXISTS update_despesas_updated_at ON public.despesas;
CREATE TRIGGER update_despesas_updated_at
    BEFORE UPDATE ON public.despesas
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

-- ============================================
-- FUNÇÃO: SINCRONIZAR USER_ID NO INSERT
-- ============================================
CREATE OR REPLACE FUNCTION public.set_user_id()
RETURNS TRIGGER AS $$
BEGIN
    NEW.user_id = auth.uid();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Triggers para setar user_id automaticamente
DROP TRIGGER IF EXISTS set_receitas_user_id ON public.receitas;
CREATE TRIGGER set_receitas_user_id
    BEFORE INSERT ON public.receitas
    FOR EACH ROW
    EXECUTE FUNCTION public.set_user_id();

DROP TRIGGER IF EXISTS set_despesas_user_id ON public.despesas;
CREATE TRIGGER set_despesas_user_id
    BEFORE INSERT ON public.despesas
    FOR EACH ROW
    EXECUTE FUNCTION public.set_user_id();

-- ============================================
-- VIEW: RESUMO FINANCEIRO (OPCIONAL)
-- ============================================
CREATE OR REPLACE VIEW public.resumo_financeiro AS
SELECT 
    r.user_id,
    COALESCE(SUM(CASE WHEN r.status = 'Confirmado' THEN r.valor ELSE 0 END), 0) as total_receitas_confirmadas,
    COALESCE(SUM(CASE WHEN r.status = 'Confirmado' AND r.recorrencia = 'mensal' THEN r.valor ELSE 0 END), 0) as mrr,
    COALESCE(SUM(CASE WHEN r.status = 'Pendente' THEN r.valor ELSE 0 END), 0) as total_receitas_pendentes,
    (SELECT COALESCE(SUM(valor), 0) FROM public.despesas d WHERE d.user_id = r.user_id) as total_despesas
FROM public.receitas r
GROUP BY r.user_id;

-- Política para a view
ALTER VIEW public.resumo_financeiro OWNER TO postgres;

-- ============================================
-- DADOS INICIAIS DE TESTE (OPCIONAL)
-- ============================================
-- Descomente se quiser dados iniciais
/*
INSERT INTO public.receitas (descricao, valor, data, status, recorrencia) VALUES
    ('Assinatura Cliente A', 15000.00, '2024-01-15', 'Confirmado', 'mensal'),
    ('Projeto Especial B', 25000.00, '2024-01-20', 'Confirmado', 'unico'),
    ('Assinatura Cliente C', 8000.00, '2024-01-25', 'Pendente', 'mensal'),
    ('Consultoria D', 12000.00, '2024-02-01', 'Confirmado', 'unico');

INSERT INTO public.despesas (descricao, valor, data, categoria, recorrencia) VALUES
    ('Fatura AWS', 4500.00, '2024-01-10', 'Infraestrutura', 'mensal'),
    ('Marketing Digital', 8000.00, '2024-01-15', 'Marketing', 'mensal'),
    ('Salários Time', 25000.00, '2024-01-05', 'Pessoal', 'mensal'),
    ('Software License', 2000.00, '2024-01-20', 'Software', 'mensal'),
    ('Impostos', 5000.00, '2024-01-25', 'Impostos', 'mensal');
*/

-- ============================================
-- PERMISSÕES ADICIONAIS
-- ============================================
GRANT ALL ON public.receitas TO authenticated;
GRANT ALL ON public.despesas TO authenticated;
GRANT ALL ON public.resumo_financeiro TO authenticated;

-- Sequências
GRANT USAGE ON ALL SEQUENCES IN SCHEMA public TO authenticated;

-- ============================================
-- REALTIME - HABILITAR PARA AS TABELAS
-- ============================================
-- Adicionar tabelas à publicação realtime
BEGIN;
  -- Remover se já existir
  DROP PUBLICATION IF EXISTS supabase_realtime;
  -- Criar nova publicação
  CREATE PUBLICATION supabase_realtime;
COMMIT;

-- Adicionar tabelas à publicação
ALTER PUBLICATION supabase_realtime ADD TABLE public.receitas;
ALTER PUBLICATION supabase_realtime ADD TABLE public.despesas;

-- ============================================
-- CONFIGURAÇÃO DE STORAGE (PARA EXPORTAÇÕES)
-- ============================================
-- Bucket para exportações (opcional)
INSERT INTO storage.buckets (id, name, public) 
VALUES ('exports', 'exports', false)
ON CONFLICT (id) DO NOTHING;

-- Política para permitir uploads de exportações
CREATE POLICY "Usuários podem fazer upload de exportações"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (bucket_id = 'exports' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Usuários podem ver suas exportações"
ON storage.objects
FOR SELECT
TO authenticated
USING (bucket_id = 'exports' AND auth.uid()::text = (storage.foldername(name))[1]);
