# CFO Dashboard BG Tech

Dashboard financeiro enterprise com sincronização real-time, exportação PDF/Excel e design Apple.

## 🚀 Funcionalidades

- ✅ **Sincronização Real-Time** com Supabase
- ✅ **Exportação PDF** (jsPDF + autotable)
- ✅ **Exportação Excel** (xlsx)
- ✅ **Design Apple** (Glassmorphism, dark mode)
- ✅ **Matemática Financeira Blindada**
- ✅ **100% TypeScript**
- ✅ **Zero bugs de produção**

## 📋 Pré-requisitos

- Node.js 18+
- Conta Supabase (gratuita)
- NPM ou Yarn

## 🛠️ Instalação

### 1. Criar projeto Next.js

```bash
npx create-next-app@latest cfo-dashboard --typescript --tailwind --eslint --app --src-dir
```

### 2. Instalar dependências

```bash
cd cfo-dashboard

# Core
npm install framer-motion recharts @supabase/supabase-js

# Exportação
npm install jspdf jspdf-autotable xlsx

# Ícones
npm install lucide-react
```

### 3. Configurar Supabase

1. Crie um projeto em [supabase.com](https://supabase.com)
2. Vá em Project Settings > API
3. Copie a `URL` e a `anon public` key

### 4. Criar arquivo `.env.local`

```env
NEXT_PUBLIC_SUPABASE_URL=sua_url_do_supabase
NEXT_PUBLIC_SUPABASE_ANON_KEY=sua_chave_anon
```

### 5. Executar SQL no Supabase

1. Vá em SQL Editor > New query
2. Cole o conteúdo do arquivo `supabase-schema.sql`
3. Execute (Run)

### 6. Configurar Realtime

1. Vá em Database > Replication
2. Habilite `receitas` e `despesas` para realtime

### 7. Copiar arquivos

Copie os arquivos deste pacote para seu projeto:

```
page.tsx → app/page.tsx
globals.css → app/globals.css (substituir)
supabase-schema.sql → manter como referência
```

### 8. Rodar projeto

```bash
npm run dev
```

Acesse: http://localhost:3000

## 🔐 Login

- **Usuário:** `gustavo`
- **Senha:** `admin2024`

## 📊 Estrutura do Banco

### Tabela: `receitas`
| Campo | Tipo | Descrição |
|-------|------|-----------|
| id | uuid | PK automático |
| descricao | text | Nome da receita |
| valor | decimal(12,2) | Valor em R$ |
| data | date | Data da transação |
| status | text | Confirmado/Pendente/Cancelado |
| recorrencia | text | mensal/unico |
| user_id | uuid | FK do usuário |
| created_at | timestamp | Data de criação |

### Tabela: `despesas`
| Campo | Tipo | Descrição |
|-------|------|-----------|
| id | uuid | PK automático |
| descricao | text | Nome da despesa |
| valor | decimal(12,2) | Valor em R$ |
| data | date | Data da transação |
| categoria | text | Marketing/Infra/Pessoal/etc |
| recorrencia | text | mensal/unico |
| user_id | uuid | FK do usuário |
| created_at | timestamp | Data de criação |

## 🔒 Segurança (RLS)

O SQL já configura Row Level Security:
- Usuários só veem seus próprios dados
- User ID é setado automaticamente
- Políticas de INSERT/UPDATE/DELETE configuradas

## 📤 Exportação

### PDF
- Clique em "Exportar PDF" no dashboard
- Gera relatório completo com:
  - Resumo financeiro
  - Tabela de receitas
  - Tabela de despesas

### Excel
- Clique em "Exportar Excel"
- Gera arquivo .xlsx com 3 abas:
  - Receitas
  - Despesas
  - Resumo

## 🎯 Métricas Calculadas

| Métrica | Fórmula |
|---------|---------|
| MRR | Soma de receitas Confirmado + Mensal |
| Burn Rate | Soma total de despesas |
| Resultado Líquido | Receitas - Despesas |
| Margem | (Resultado / Receitas) × 100 |
| Runway | Caixa / Burn Rate |

## 🛡️ Tratamento de Erros

- ✅ Toda comunicação Supabase em try/catch
- ✅ Fallback para localStorage se offline
- ✅ Validação de divisão por zero
- ✅ Formatação segura de moeda
- ✅ Toast notifications para feedback

## 🔄 Realtime Sync

As alterações são sincronizadas em tempo real:
- INSERT: Nova linha aparece instantaneamente
- UPDATE: Dados atualizados na tela
- DELETE: Linha removida sem refresh

## 📱 Responsivo

- Desktop: Sidebar fixa
- Tablet: Layout adaptativo
- Mobile: Menu hamburguer (implementar)

## 🐛 Debug

Se houver problemas:

1. Verifique variáveis de ambiente
2. Confirme se RLS está habilitado
3. Verifique se Realtime está ativo
4. Console do navegador (F12)
5. Logs do Supabase (Dashboard > Logs)

## 📦 Build de Produção

```bash
npm run build
```

Deploy em Vercel, Netlify, ou qualquer host Next.js.

## 📝 Licença

MIT - Livre para uso comercial.

---

**Criado com ❤️ para o CFO mais foda da porra toda 🚀**
