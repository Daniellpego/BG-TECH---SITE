import type { Config } from 'tailwindcss'

const config: Config = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  darkMode: 'class',
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        display: ['Plus Jakarta Sans', 'Inter', 'sans-serif'],
      },
      colors: {
        apple: {
          bg: '#000000',
          card: '#1c1c1e',
          cardHover: '#2c2c2e',
          border: '#38383a',
          text: '#ffffff',
          textSecondary: '#8e8e93',
          accent: '#0a84ff',
          accentHover: '#409cff',
          success: '#30d158',
          warning: '#ff9f0a',
          danger: '#ff453a',
          purple: '#bf5af2',
          cyan: '#5ac8fa',
          orange: '#ff9500',
        },
      },
      backdropBlur: {
        apple: '20px',
      },
    },
  },
  plugins: [],
}

export default config
